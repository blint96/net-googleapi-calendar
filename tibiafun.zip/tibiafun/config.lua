---------------------------- OTServ configuration ------------------------------

-- datadir
datadir = "data/"

-- sets what map to load
map = "data/world/test.otbm"

-- OTBM for binary, SQL for SQL map, XML for OTX maps
mapkind = "OTBM"

-- SQL for acc/player info from SQL, XML for acc/player info from XML
sourcedata = "XML"

-- the message the player gets when he logs in
loginmsg = "Welcome to TibiaFun III the next Generation of TibiaFun."

-- the port otserv listens on
port = "7172"

-- name of our server
servername = "TibiaFun III"

-- name of the owner of our server
ownername = "Team TibiaFun"

-- email of the owner of our server
owneremail = "tibiafun@mail.org"

-- the url for more server info
url = "http://tibiafun.net"

-- the location of the server
location = "Germany"

-- the ip the server should redirect too (auto - set as first local ip)
ip = "87.118.118.30"

-- The messagebox you sometimes get before you choose characters
motd = "Welcome to TibiaFun WAR III!\nVisit our Hompepage www.tibiafun.net!"
motdnum="2"

-- use md5 passwords for accounts, yes/no
md5passwords = "no"

-- world type. options: pvp, no-pvp, pvp-enforced
worldtype = "pvp"

-- max number of players allowed
maxplayers = "100"

-- exhausted time in ms (1000 = 1sec)
exhausted = 1000

-- exhaustion time for healing spells (1000 = 1sec)
exhaustedheal = 150

-- how many ms to add if the player is already exhausted and tries to cast a spell (1000 = 1sec)
exhaustedadd = 100

-- how long does the player has to stay out of fight to get pz unlocked in ms (1000 = 1sec)
pzlocked = 45*1000

-- allow multiple logins of the same char
allowclones = 0

-- vocation names
vocations = {"a master mage", "an elder druid", "a royal paladin", "an elite knight"}
promoted_vocations = {"a master mage", "an elder druid", "a royal paladin", "an elite knight"}


--- SQL part
sql_host = "localhost"
sql_user = "root"
sql_pass = ""
sql_db   = "otserv"


--- SQL MAP part
sqlmap = "test_map"
map_host = "localhost"
map_user = "root"
map_pass = ""
map_db   = ""

------------------------- YurOTS basic configuration ---------------------------

-- name of your world (seen on the character list when logging in)
worldname = "TibiaFun III"

-- how often do server saves it's state (0 = off, 5 = 5min, 60 = hour)
autosave = 15

-- builtin account maker (rook/main/none)
accmaker = "rook"

-- do you want to enable cap system? (yes/no)
capsystem = "yes"

-- do you want players to learn spells before they can use them? (yes/no)
learnspells = "no"

-- do you want to give premium account to all players? (yes/no)
freepremmy = "yes"

-- do you want premium players to wait in queue as others? (yes/no)
queuepremmy = "yes"

-- how much % of {exp, mana, skill, eq, bp} do you lose when dying
diepercent = {"3.5", "4", "5", "8", "100"}
diepercent = {"3.5", "4", "5", "8", "100"}

-- how many summons player can have
maxsummons = 0

-- do you want to give summons for all vocations? (yes/no)
summonsallvoc = "no"

-- chance of losing a spear when shot (0 - none lost, 100000 - all lost)
spearlosechance = 100000

-- anti-afk - maximum idle time to kick player (1 = 1min)
kicktime = 30

-- maximum number of items player can keep in his/her depot
maxdepotitems = 2000

-- maximum number of items on a house tile (including those in containers)
maxhousetileitems = 20

-- how much death entries are saved in players file (old are deleted)
maxdeathentries = 8

-- mana consumend by {snakebite, moonlight, volcanic, quagmire, tempest} rod
rodmana = {"2", "3", "5", "8", "13"}

-- mana consumed by wand of {vortex, dragonbreath, plague, cosmic energy, inferno}
wandmana = {"2", "3", "5", "8", "13"}

-- shooting range of {snakebite, moonlight, volcanic, quagmire, tempest} rod
rodrange = {"10", "10", "10", "10", "10"}

-- shooting range of  wand of {vortex, dragonbreath, plague, cosmic energy, inferno}
wandrange = {"10", "10", "10", "10", "10"}

-- damage of burst arrows blast
-- default is from (1*lvl+5*mlvl)*0.24 to (1*lvl+5*mlvl)*0.55
burstarrowdmg = {"0.5", "8.0", "0.2", "0.4"}

--------------------------- Multipliers and gains ------------------------------

-- experience multiplier (how much faster you got exp from monsters)
expmul = 10

-- experience multiplier for pvp-enforced (how much faster you got exp from players)
expmulpvp = 0

-- skill multipliers: 1 - rl tibia, 10 - ten times faster etc. {no-voc, sorcerer, druid, paladin, knight}
weaponmul = {"3", "17", "17", "3", "43"}
distmul = {"3", "3", "3", "38", "3"}
shieldmul = {"3", "3", "30", "43", "48"}
manamul = {"3", "35", "45", "10", "5"}

-- how much points of life,mana,cap do you get when advancing {no-voc, sorcerer, druid, paladin, knight}
capgain = {"10", "10", "10", "20", "25"}
managain = {"10", "60", "30", "20", "10"}
hpgain = {"10", "10", "10", "25", "30"}

-- how much faster do you recovery life,mana after eating food (1 - rl tibia)
healthtickmul = 80
manatickmul = 180

-------------------------------- Skull system ----------------------------------
-- unjustified kill time (1 = 1min)
whiteskulltime = 8

-- redskull time (1 = 1min)
redskulltime = 90

-- unjustified kills to get a red skull
redskull = 6

-- unjustified kills to get banned
redskullban = 8

-- how many unjustified kills to get a red skull
redunjust = 4

-- how many unjustified kills to get banned
banunjust = 8

--bantime of unjustified playerkillers
pkbandays = 2

-- how long do you have white skull after attacking player (1 = 1min)
hittime = 2

-- how long do you have white skull after killing player (1 = 1min)
whitetime = 10

-- how long do you have red skull (1 = 1min)
redtime = 5*60

-- how long do you have to wait to lose 1 unjustified kill (1 = 1min)
fragtime = 60

------------------------------ GM access rights --------------------------------

-- access to walk into houses and open house doors
accesshouse = 4

-- access to login without waiting in the queue or when server is closed
accessenter = 1

-- access to ignore damage, exhaustion, cap limit and be ignored by monsters
accessprotect = 4

-- access to broadcast messages and talk in colors (#c blabla - in public channels)
accesstalk = 1

-- access to move distant items from/to distant locations
accessremote = 4

-- access to see id and position of the item you are looking at
accesslook = 3

-- speed of attack in seconds (no-voc, sorc, druid, pally, knight)
speed = {"0.3", "0.25", "0.25", "0.2", "0.15"}

-- XP changing by level --
-- stage{NUMBER} means the UP TO LEVEL --
-- stage{NUMBER}x means the MULTIPLIER rate --
-- lvl 0 to stage1
stage1 = 20
stage1x = 10

-- up to stage2
stage2 = 50
stage2x = 10

-- up to stage3
stage3 = 120
stage3x = 10

-- up to stage4
stage4 = 160
stage4x = 10

-- up to stage5
stage5 = 200
stage5x = 10

-- up to stage6
stage6 = 240
stage6x = 10

-- after stage6 it will be forever constant
stage7x = 10

--How many mana and Hp you recovery using Soft Boots
softmana = "50"
softhealth = "100"

--Auto Save time for each player.... 1 = 1min
saveTime = 10


-- house price for 1 sqm
priceforsqm = 200000

-- max houses for player
maxhouses = 1

-- Life Ring Configuration
LifeRingHealth = "25"
LifeRingMana = "25"

-- ROH Configuration
RoHHealth = "50"
RoHMana = "50"

-- XP changing by level --
-- stage{NUMBER} means the UP TO LEVEL --
-- stage{NUMBER}x means the MULTIPLIER rate --
-- lvl 0 to stage1
stage1 = 300
stage1x = 7

-- up to stage2
stage2 = 500
stage2x = 9

-- up to stage3
stage3 = 600
stage3x = 10

-- up to stage4
stage4 = 700
stage4x = 8

-- up to stage5
stage5 = 800
stage5x = 6

-- up to stage6
stage6 = 900
stage6x = 5

-- after stage6 it will be forever constant
stage7x = 3

---- UCB Suspend System (April/2006)
-- Suspend time period (in minuts)
suspend_time_max = 1

-- Acc tries to be suspended in the period
suspend_acc_tries = 8

-- Same IP loggin tries to be suspended in the period
suspend_ip_tries = 10

-- Message to user when he got suspended
suspendmsg = "Your IP/ACC has been suspended for 1 minute. Every try before will add 1 min."

-- Access to use GM Command Window Tool
accessGMtool = 5

-- should GM be anonymous
GM_Anonymity = "yes"

-- Auto Restart (in minutes)
autorestart = 12*60

----------------------------- Rings configuration ----------------------------------

-- How many additionaly sword points should player get during to using Sword Ring
SwordRing = 10

-- How many additionaly axe points should player get during to using Axe Ring
AxeRing = 10

-- How many additionaly club points should player get during to using Club Ring
ClubRing = 10

-- How many additionaly shielding points should player get during to using Dwarven Ring
DwarvenRing = 50

-- How many additionaly distance points should player get during to using Crystal Ring (ID: 2124)
DistRing = 10

-- How many additionaly fist points should player get during to using Power Ring
PowerRing = 12

-- How much faster do you recovery life and mana when you have Life Ring
LifeRingHealth = "20"
LifeRingMana = "20"

-- How much faster do you recovery life and mana when you have Ring of Healing
RoHHealth = "50"
RoHMana = "50"

-- id of "Ring of Lose"(works like aol, but it's ring)
ringoflose_id = 2357

--id of bless amulet (you don't lose anything when dying)
blessamulet_id = 2196

--damage of wands and rods (X * level + X * mlvl + X)

quagmire_rod_min = {0,0,0}
quagmire_rod_max = {0,0,0}

snakebite_rod_min = {0,0,0}
snakebite_rod_max = {0,0,0}

tempest_rod_min = {0,0,0}
tempest_rod_max = {0,0,0}

volcanic_rod_min = {0,0,0}
volcanic_rod_max = {0,0,0}

moonlight_rod_min = {0,0,0}
moonlight_rod_max = {0,0,0}

wand_of_inferno_min = {0,0,0}
wand_of_inferno_max = {0,0,0}

wand_of_plague_min = {0,0,0}
wand_of_plague_max = {0,0,0}

wand_of_cosmic_energy_min = {0,0,0}
wand_of_cosmic_energy_max = {0,0,0}

wand_of_vortex_min = {0,0,0}
wand_of_vortex_max = {0,0,0}

wand_of_dragonbreath_min = {0,0,0}
wand_of_dragonbreath_max = {0,0,0}

-- how often can player send messages in Trade-Channel (in seconds)
tradechannel_time = 120


-- exhausted time for using exura spells (! only spells with prefix "exura" in words!) in ms (0 - no exhausted, 500 - 0,5 sec, 1000 - sec etc.)
exura_exhausted = 100

-- exhausted time added if someone is trying to cast exura when exhausted in ms (0 - no add, 100 - 0,1 sec, 500 - 0,5 sec etc.)
exura_add = 0

-- weapons' damage multipliers 
-- fightmode * (((skill * X1) / (weapondmg /X2)) * weapondmg + (level * X3) + ((skill*skill) /X4))
-- weapons' damage multipliers (fightmode * ((skilllevel*1X)/(weapondmg/2X)) * weapondmg + (level * 3X))

fist_mul = {1,1,1,1}
-- weapons' damage multipliers 
-- fightmode * skill * weapondmg/X1 + weapondmg + ((skill*level)/X2)
-- axe
axe_mul = {"20","50"}
-- sword
sword_mul = {"20","50"}
-- club
club_mul = {"20","50"}
-- distance
dista_mul = {"20","50"}



-- magic damage multiplier (s wand etc)((level * X + maglevel*X)*X)
magic_mul = {0.9,9,1.5}

-- defense multiplier (how many times should it be counted higher)
def_mul = 1

-- defense redution in % (1 = 1% of dmg is reduced by ONE defense point) !! must be in ""
def_red = "0.1"

-- should player be rejected if character is online and someone is trying to log in
rejection = "yes"

-- character list type - text in () after player's nick (1 - "<voc> <level>"; 2 - "offline/online")
playerlisttype = 1

--Nayeli login
NayeliSpawn = "no"

-- should yellow skull system be enabled?
enable_yellow_skull = "yes"

-- how long should yellow skull be active? (in seconds)
yellow_skull_time = 300

-- how long should player wait to leave protection zone after logging in ? (in secodns)
leave_pz_time = 5

-- auto broadcasts (leave empty to turn off) (max 10)
broadcasts = {"Join TibiaFun community, be part of us: http://tibiafun.de", "Houses will be available soon. Don't ask for it by then", "", ""}

-- time between broadcasts (in minutes)
broadcast_time = 15

