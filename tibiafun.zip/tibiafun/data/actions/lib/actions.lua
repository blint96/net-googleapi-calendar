function exhaust(cid, storevalue, exhausttime)
	newExhaust = os.time()
	oldExhaust = getPlayerStorageValue(cid, storevalue)
	if (lastexhaust == nil or lastexhaust < 0) then
		lastexhaust = 0
	end
	if (exhausttime == nil or exhausttime < 0) then
		exhausttime = 1
	end
	diffTime = os.difftime(newExhaust, oldExhaust)
	if (diffTime >= exhausttime) then
		setPlayerStorageValue(cid, storevalue, newExhaust)
		return 1
	else
		return 0
	end
end

function exhaust(cid, storevalue, exhausttime)
-- Exhaustion function by Alreth, v1.1 2006-06-24 01:31
-- Returns 1 if not exhausted and 0 if exhausted
    
    newExhaust = os.time()
    oldExhaust = getPlayerStorageValue(cid, storevalue)
    if (oldExhaust == nil or oldExhaust < 0) then
        oldExhaust = 0
    end
    if (exhausttime == nil or exhausttime < 0) then
        exhausttime = 1
    end
    diffTime = os.difftime(newExhaust, oldExhaust)
    if (diffTime >= exhausttime or diffTime < 0) then
        setPlayerStorageValue(cid, storevalue, newExhaust) 
        return 1
    else
        return 0
    end
end

-- Return ingame time
function tibiatime()
    return rl2tib(os.date('%M'), os.date('%S'), true)
end

-- Convert RL time to ingame Tibia time - by Alreth (v1.13)
function rl2tib(min, sec, twentyfour)
    suffix = ''
    varh = (min*60+sec)/150
    tibH = math.floor(varh)             -- Tibian hour
    tibM = math.floor(60*(varh-tibH))   -- Tibian minute
    
    if (twentyfour == false) then
        if (tonumber(tibH) > 11) then
            tibH = tonumber(tibH) - 12
            suffix = ' pm'
        else
            suffix = ' am'
        end
        if (tibH == 0) then
            tibH = 12
        end
    end
    if (tibH < 10) then
        tibH = '0'..tibH
    end
    if (tibM < 10) then
        tibM = '0'..tibM
    end
    return (tibH..':'..tibM..suffix)
end
