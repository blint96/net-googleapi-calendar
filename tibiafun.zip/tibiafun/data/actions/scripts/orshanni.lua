-- annihilator chests

function onUse(cid, item, frompos, item2, topos)

   	if item.uid == 6503 then
   		queststatus = getPlayerStorageValue(cid,6506)
   		if queststatus == -1 then
   			doPlayerSendTextMessage(cid,22,"You have found a sprite wand.")
   			doPlayerAddItem(cid,2453,1)
   			setPlayerStorageValue(cid,6506,1)
   		else
   			doPlayerSendTextMessage(cid,22,"It is empty.")
   		end
   	elseif item.uid == 6504 then
   		queststatus = getPlayerStorageValue(cid,6506)
   		if queststatus == -1 then
   			doPlayerSendTextMessage(cid,22,"You have found a ice rapier.")
   			doPlayerAddItem(cid,2396,1)
   			setPlayerStorageValue(cid,6506,1)
   		else
   			doPlayerSendTextMessage(cid,22,"It is empty.")
   		end
   	elseif item.uid == 6505 then
   		queststatus = getPlayerStorageValue(cid,6506)
   		if queststatus == -1 then
   			doPlayerSendTextMessage(cid,22,"You have found a crystal arrow.")
   			doPlayerAddItem(cid,2352,1)
   			setPlayerStorageValue(cid,6506,1)
   		else
   			doPlayerSendTextMessage(cid,22,"It is empty.")
   		end
	else
		return 0
   	end

   	return 1
end
