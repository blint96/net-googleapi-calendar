function onUse(cid, item, frompos, item2, topos)

stairpos = {x=261, y=892, z=2, stackpos=1}  
stair = getThingfromPos(stairpos)  



if item.uid == 1201 and item.itemid == 1504 then 

doTransformItem(item.uid,1495)
doPlayerSendTextMessage(cid,22,"Stairs appeared.") 
doSendMagicEffect(stairpos, 2) 
doCreateItem(3688,1,stairpos) 
print("Stairs on R7Q Created.")




elseif item.uid == 1201 and item.itemid == 1495 then
doTransformItem(item.uid,1504)
doSendMagicEffect(stairpos, 2) 
doRemoveItem(stair.uid,1)
print("Stairs on R7Q Removed.")

end


return 1

end

