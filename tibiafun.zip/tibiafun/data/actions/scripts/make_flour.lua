 
--Make wheat to flour by Darkpower--
function onUse(cid, item, frompos, item2, topos)
if item2.itemid == 0 then
return 0
end
if item2.itemid == 1382 then 
   doRemoveItem(item.uid,1)
   doCreateItem(2692,1,topos)
 else
   return 0
 end
   return 1
end