function onUse(cid, item, frompos, item2, topos)
minmana = getPlayerMana(cid)

if minmana < 50 then
doPlayerSendCancel(cid,"You need more mana")

elseif item.itemid == 2699 then
doPlayerAddMana(cid, -50) 
doPlayerSendCancel(cid,"You created an adori blank rune.")
doPlayerAddItem(cid, 2260, 100)
else
doPlayerSendCancel(cid,"You need more mana.")

end
end