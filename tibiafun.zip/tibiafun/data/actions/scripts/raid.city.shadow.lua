function onUse(cid, item, frompos, item2, topos)
if item.uid == 9170 and item.itemid == 1945 then

king1pos = {x=146, y=110, z=7, stackpos=1}
king2pos = {x=280, y=306, z=7, stackpos=1}
king3pos = {x=717, y=763, z=7, stackpos=1}

kingpos = math.random(1,3)
if kingpos == 1 then
	doSummonCreature("Shadow Wolf King",king1pos)
	elseif kingpos == 2 then
	doSummonCreature("Shadow Wolf King",king2pos)
	elseif kingpos == 3 then
	doSummonCreature("Shadow Wolf King",king3pos)
end

orc1pos = {x=145, y=113, z=7, stackpos=1}
orc2pos = {x=150, y=111, z=7, stackpos=1}
orc3pos = {x=148, y=116, z=7, stackpos=1}
orc4pos = {x=145, y=119, z=7, stackpos=1}
orc5pos = {x=158, y=120, z=7, stackpos=1}
orc6pos = {x=158, y=115, z=7, stackpos=1}
orc7pos = {x=168, y=114, z=7, stackpos=1}
orc8pos = {x=164, y=102, z=7, stackpos=1}
orc9pos = {x=177, y=110, z=7, stackpos=1}
orc10pos = {x=170, y=95, z=7, stackpos=1}

orc11pos = {x=295, y=313, z=7, stackpos=1}
orc12pos = {x=287, y=312, z=7, stackpos=1}
orc13pos = {x=277, y=311, z=7, stackpos=1}
orc14pos = {x=269, y=313, z=7, stackpos=1}
orc15pos = {x=260, y=315, z=7, stackpos=1}
orc16pos = {x=260, y=317, z=7, stackpos=1}
orc17pos = {x=271, y=319, z=7, stackpos=1}
orc18pos = {x=280, y=300, z=7, stackpos=1}
orc19pos = {x=278, y=292, z=7, stackpos=1}
orc20pos = {x=285, y=292, z=7, stackpos=1}
orc21pos = {x=289, y=297, z=7, stackpos=1}
orc22pos = {x=296, y=293, z=7, stackpos=1}

orc23pos = {x=722, y=772, z=7, stackpos=1}
orc24pos = {x=730, y=773, z=7, stackpos=1}
orc25pos = {x=710, y=771, z=7, stackpos=1}
orc26pos = {x=701, y=770, z=7, stackpos=1}
orc27pos = {x=695, y=771, z=7, stackpos=1}
orc28pos = {x=671, y=772, z=7, stackpos=1}
orc29pos = {x=671, y=764, z=7, stackpos=1}
orc30pos = {x=674, y=759, z=7, stackpos=1}
orc31pos = {x=673, y=751, z=7, stackpos=1}
orc32pos = {x=683, y=752, z=7, stackpos=1}
orc33pos = {x=697, y=752, z=7, stackpos=1}

doPlayerSay(cid,'/nbc green A howl goes round on Tibiafun. The shadows move and kill everyone who is in their way. Watch out mortal. You can be the next.',23)

doSummonCreature("Shadow Wolf",orc1pos)
doSummonCreature("Shadow Wolf",orc2pos)
doSummonCreature("Shadow Wolf",orc3pos)
doSummonCreature("Shadow Wolf",orc4pos)
doSummonCreature("Shadow Wolf",orc5pos)
doSummonCreature("Shadow Wolf",orc6pos)
doSummonCreature("Shadow Wolf",orc7pos)
doSummonCreature("Shadow Wolf",orc8pos)
doSummonCreature("Shadow Wolf",orc9pos)
doSummonCreature("Shadow Wolf",orc10pos)
doSummonCreature("Shadow Wolf",orc11pos)
doSummonCreature("Shadow Wolf",orc12pos)
doSummonCreature("Shadow Wolf",orc13pos)
doSummonCreature("Shadow Wolf",orc14pos)
doSummonCreature("Shadow Wolf",orc14pos)
doSummonCreature("Shadow Wolf",orc15pos)
doSummonCreature("Shadow Wolf",orc16pos)
doSummonCreature("Shadow Wolf",orc17pos)
doSummonCreature("Shadow Wolf",orc18pos)
doSummonCreature("Shadow Wolf",orc19pos)
doSummonCreature("Shadow Wolf",orc20pos)
doSummonCreature("Shadow Wolf",orc21pos)
doSummonCreature("Shadow Wolf",orc22pos)
doSummonCreature("Shadow Wolf",orc23pos)
doSummonCreature("Shadow Wolf",orc24pos)
doSummonCreature("Shadow Wolf",orc25pos)
doSummonCreature("Shadow Wolf",orc26pos)
doSummonCreature("Shadow Wolf",orc27pos)
doSummonCreature("Shadow Wolf",orc28pos)
doSummonCreature("Shadow Wolf",orc29pos)
doSummonCreature("Shadow Wolf",orc30pos)
doSummonCreature("Shadow Wolf",orc31pos)
doSummonCreature("Shadow Wolf",orc32pos)
doSummonCreature("Shadow Wolf",orc33pos)


doSendMagicEffect(orc1pos,10)


doSendMagicEffect(orc1pos,11)


doSendMagicEffect(orc1pos,12)




doTransformItem(item.uid,item.itemid+1)
end
	if item.uid ==9170 and item.itemid == 1946 then
		if getPlayerAccess(cid) > 0 then
			doTransformItem(item.uid,item.itemid-1)
		else
			doPlayerSendCancel(cid,"Sorry, not possible.")
		end
	else
		return 0
	end
return 1
end