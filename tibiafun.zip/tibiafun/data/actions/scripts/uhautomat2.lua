function onUse(cid, item, frompos, item2, topos)
if item.itemid == 2593 and doPlayerRemoveMoney(cid,3000) == 1 then

doPlayerAddItem(cid, 2273, 100)
else
doPlayerSendCancel(cid,"You need more money.")
return 1
end
end