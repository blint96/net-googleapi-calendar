-- D Zone secret way


function onUse(cid, item, frompos, item2, topos)
doorlevel = 700
playerset1 = 0
player1 = 0
if (doPlayerRemoveItem(cid,2363,1)) then
if item.uid == 9171 and item.itemid == 1546 then

		player1pos = {x=218, y=844, z=8, stackpos=253}
		player1 = getThingfromPos(player1pos)
	

		
		if player1.itemid > 0 then
			player1level = getPlayerLevel(player1.uid)
			playerset1 = 1
			if (player1level < doorlevel) then
				playerset1 = 0
				doPlayerSendTextMessage(player1.uid,22,"You are not ready to enter this area")
			end
		end
				
		for secretx = 218,218 do	
			for secrety = 845,844 do
				secretpos = {x=secretx, y=secrety, z=8, stackpos=253}
				
			end
		end
	if playerset1 == 1 then
		nplayer1pos = {x=214, y=846, z=9}
		doSendMagicEffect(player1pos,5)
		doTeleportThing(player1.uid,nplayer1pos)
		doSendMagicEffect(nplayer1pos,5)

	end
		
	
else
	
return 0
end
else
	doPlayerSendTextMessage(cid,22,"You need a soul apple to pass")
end

end
