function onUse(cid, item, frompos, item2, topos)

click_status = getPlayerStorageValue(cid,9505)

centerpos = {x=259, y=888, z=4, stackpos=1}   
center = getThingfromPos(centerpos)

wallpos1 = {x=259, y=887, z=4, stackpos=1}   
wall1 = getThingfromPos(wallpos1)  

wallpos2 = {x=260, y=887, z=4, stackpos=1}   
wall2 = getThingfromPos(wallpos2)  

wallpos3 = {x=260, y=888, z=4, stackpos=1}   
wall3 = getThingfromPos(wallpos3)  

wallpos4 = {x=260, y=889, z=4, stackpos=1}   
wall4 = getThingfromPos(wallpos4)  

wallpos5 = {x=259, y=889, z=4, stackpos=1}   
wall5 = getThingfromPos(wallpos5)  

wallpos6 = {x=258, y=889, z=4, stackpos=1}   
wall6 = getThingfromPos(wallpos6)  

wallpos7 = {x=258, y=888, z=4, stackpos=1}   
wall7 = getThingfromPos(wallpos7) 

wallpos8 = {x=258, y=887, z=4, stackpos=1}   
wall8 = getThingfromPos(wallpos8) 



if item.itemid == 3943 and item.uid == 9505
doTransformItem(item.uid,item.itemid+1) 
doPlayerSendTextMessage(cid,22,"Knaack") 
doSendMagicEffect(centerpos, 2) 
doRemoveItem(wall1.uid,1)
doRemoveItem(wall2.uid,1)
doRemoveItem(wall3.uid,1)
doRemoveItem(wall4.uid,1)
doRemoveItem(wall5.uid,1)
doRemoveItem(wall6.uid,1)
doRemoveItem(wall7.uid,1)
doRemoveItem(wall8.uid,1)
setPlayerStorageValue(cid,9505,1)



elseif item.itemid == 3812 and item.uid == 9505
doTransformItem(item.uid,item.itemid+1) 
doPlayerSendTextMessage(cid,22,"Knock") 
doSendMagicEffect(centerpos, 2) 
doCreateItem(1171,1,wallpos1)
doCreateItem(1171,1,wallpos2)
doCreateItem(1170,1,wallpos3)
doCreateItem(1173,1,wallpos4)
doCreateItem(1171,1,wallpos5)
doCreateItem(1170,1,wallpos6)
doCreateItem(1170,1,wallpos7)
doCreateItem(1172,1,wallpos8)
setPlayerStorageValue(cid,9505,-1)

else
doPlayerSendTextMessage(cid,22,"Are you sure you did everything like it had to be done?") 
print("R7Q - Player got lost.")


end


return 1

end

