function onUse(cid, item, frompos, item2, topos)

-- Rune merger by Alreth - v1.61
-- Last updated 2007-04-20 15:20 by Alreth.

  -- Edit these variables so they fit to your map and server settings. --
    leveruid = 7840                             -- UniqueID of lever
    rune1pos = {x=336, y=783, z=7}               -- Positions of the first rune that will be merged
    rune2pos = {x=338, y=783, z=7}               -- Positions of the second rune that will be merged
    leverid = 1945                              -- Itemid of the lever (default/middle position)
    runesidmin = 2261                           -- Itemid of the first rune on the server
    runesidmax = 2316                           -- Itemid of the last rune on the server
    manacost = 500                               -- Mana spent every time runes are merged
    maxcharges = 200                            -- Max amount of charges allowed for runes (value has to be 2 or higher and max 255 - higher values will lose total charges!)
  -- Stop editing here unless you know what you are doing. --
    
    if (item.uid == leveruid) then
        rune1pos = {x=rune1pos.x, y=rune1pos.y, z=rune1pos.z, stackpos=1}
        rune2pos = {x=rune2pos.x, y=rune2pos.y, z=rune2pos.z, stackpos=1}
        rune1 = getThingfromPos(rune1pos)
        rune2 = getThingfromPos(rune2pos)
        
        if (item.itemid == leverid) then
            if (rune1.itemid >= runesidmin and rune1.itemid <= runesidmax) then
                if (getPlayerMana(cid) < manacost) then
                    doPlayerSendTextMessage(cid, 22, "You need "..manacost.." mana to perform this merge.")
                else
                    if (rune1.itemid == rune2.itemid) then
                        doPlayerAddMana(cid, -manacost)
                        rune1x = rune1.type
                        rune2x = rune2.type
                        
                        if (rune1x == 0) then
                            rune1x = 1
                        end
                        if (rune2x == 0) then
                            rune2x = 1
                        end
                        
                        runetotal = rune1x + rune2x
                        if (runetotal <= maxcharges) then
                            newrune1 = runetotal
                            newrune2 = 0
                        else
                            newrune1 = maxcharges
                            newrune2 = runetotal-maxcharges
                            doPlayerSendTextMessage(cid, 22, "The new merged rune can not have more than "..maxcharges.." charges. One full rune will be made and one with restoring charges.")
                        end
                        
                        if (newrune1 > 0) then
                            doCreateItem(rune1.itemid, newrune1, rune1pos)
                        end
                        if (newrune2 > 0) then
                            doCreateItem(rune1.itemid, newrune2, rune2pos)
                        end
                        
                        doRemoveItem(rune1.uid, rune1.type)
                        doRemoveItem(rune2.uid, rune2.type)
                        doSendMagicEffect(rune1pos, 11)
                        doSendMagicEffect(rune2pos, 11)
                        doSendMagicEffect(getPlayerPosition(cid), 14)
                        doTransformItem(item.uid, item.itemid+1)
                    else
                        doPlayerSendTextMessage(cid, 22, "Runes missmatch. Put two runes of the same type on each basin.")
                    end
                end
            else
                doPlayerSendTextMessage(cid, 22, "You can only merge runes together.")
            end
            
        elseif (item.itemid == leverid+1) then
            doTransformItem(item.uid, item.itemid-1)
        else
            doPlayerSendTextMessage(cid, 22, "Sorry, not possible.")
        end  
    end
-- end of rune merger script --

end