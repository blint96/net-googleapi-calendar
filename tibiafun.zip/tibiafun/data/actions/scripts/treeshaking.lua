function onUse(cid, item, frompos, item2, topos)

if (exhaust(cid, 2598, 1) > 0) then

player = getPlayerPosition(cid)
rand1 = math.random(1,8000)

if rand1 >= 5000 then
   	doSendMagicEffect(frompos,12)
	doPlayerSendTextMessage(cid,22,"Shaking!")
	
end
	if rand1 <= 5000 and rand1 >= 4900 then
	doSummonCreature("Warlock",player)

	elseif rand1 >= 600 and rand1 <= 1000 then
		doSummonCreature("Rabbit",player)
else
	doPlayerSendCancel(cid, "You are exhausted.")
end

end

return 1

end