function onUse(cid, item, frompos, item2, topos)
player1pos = getPlayerPosition(cid)
player1 = getThingfromPos(player1pos)
if player1.itemid > 0 then
temple = {x=268, y=245, z=7}
doSendMagicEffect(topos,12)
doTeleportThing(topos,temple)
doSendMagicEffect(temple,12)
doPlayerSendTextMessage(player1.uid,22,"You have been teleported to the temple by the powers of this mystical rune.")
doRemoveItem(item.uid,2295)
end
end