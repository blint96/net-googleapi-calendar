--Example summon--


function onUse(cid, item, frompos, item2, topos)

	doSummonCreature("demon", frompos)
	
	return 1
end