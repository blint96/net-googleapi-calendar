
function onUse(cid, item, frompos, item2, topos)

   	if item.uid == 6510 then
   		queststatus = getPlayerStorageValue(cid,6510)
   		if queststatus == -1 then
   			doPlayerSendTextMessage(cid,22,"You have found a Labrys")
   			doPlayerAddItem(cid,2435,1)
   			setPlayerStorageValue(cid,6513,1)
   		else
   			doPlayerSendTextMessage(cid,22,"It is empty.")
   		end
   	elseif item.uid == 6711 then
   		queststatus = getPlayerStorageValue(cid,6711)
   		if queststatus == -1 then
   			doPlayerSendTextMessage(cid,22,"You have found Verminor's helmet")
   			doPlayerAddItem(cid,2506,1)
   			setPlayerStorageValue(cid,6513,1)
   		else
   			doPlayerSendTextMessage(cid,22,"It is empty.")
   		end
   	elseif item.uid == 6712 then
   		queststatus = getPlayerStorageValue(cid,6712)
   		if queststatus == -1 then
   			doPlayerSendTextMessage(cid,22,"You have found Verminor's poison arrow")
   			doPlayerAddItem(cid,2545,1)
   			setPlayerStorageValue(cid,6513,1)
   		else
   			doPlayerSendTextMessage(cid,22,"It is empty.")
   		end
	else
		return 0
   	end

   	return 1
end