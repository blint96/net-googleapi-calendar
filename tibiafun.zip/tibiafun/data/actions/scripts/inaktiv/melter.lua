function onUse(cid, item, frompos, item2, topos)
piece1pos = {x=206, y=635, z=7, stackpos=1}
piece2pos = {x=207, y=635, z=7, stackpos=1}
piece3pos = {x=208, y=635, z=7, stackpos=1}
piece4pos = {x=209, y=635, z=7, stackpos=1}
piece5pos = {x=210, y=635, z=7, stackpos=1}
piece6pos = {x=211, y=635, z=7, stackpos=1}
piece7pos = {x=212, y=635, z=7, stackpos=1}
getpiece1 = getThingfromPos(piece1pos)
getpiece2 = getThingfromPos(piece2pos)
getpiece3 = getThingfromPos(piece3pos)
getpiece4 = getThingfromPos(piece4pos)
getpiece5 = getThingfromPos(piece5pos)
getpiece6 = getThingfromPos(piece6pos)
getpiece7 = getThingfromPos(piece7pos)
playerpos = getPlayerPosition(cid)
nplayer1pos = {x=205, y=631, z=7}
createpos = {x=205, y=626, z=7}

if item.uid == 7202 and item.itemid == 1945 and getpiece1.itemid == 2128 and getpiece2.itemid == 2466 and getpiece3.itemid == 2470 and getpiece4.itemid == 2475 and getpiece5.itemid == 2646 and getpiece6.itemid == 3058 and getpiece7.itemid == 2130 then
      playerpos = getPlayerPosition(cid)
            doSendMagicEffect(playerpos,2)
      doTeleportThing(cid,nplayer1pos)
            doSendMagicEffect(nplayer1pos,10)
 doRemoveItem(getpiece1.uid,1)
 doRemoveItem(getpiece2.uid,1)
 doRemoveItem(getpiece3.uid,1)
 doRemoveItem(getpiece4.uid,1)
 doRemoveItem(getpiece5.uid,1)
 doRemoveItem(getpiece6.uid,1)
 doRemoveItem(getpiece7.uid,1)
 doTransformItem(item.uid,item.itemid+1)
 doPlayerSendTextMessage(cid,22,'You have made a ' .. getItemName(2523) .. '.')
 doCreateItem(2523,1,createpos)
 setPlayerStorageValue(cid,2523,1)
 
elseif item.uid == 7202 and item.itemid == 1946 then
doTransformItem(item.uid,item.itemid-1)
 else
doPlayerSendTextMessage(cid,22,"Sorry, not possible.")
end
return 1
end