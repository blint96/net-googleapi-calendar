
function onUse(cid, item, frompos, item2, topos)

   	if item.uid == 6503 then
   		queststatus = getPlayerStorageValue(cid,6503)
   		if queststatus == -1 then
   			doPlayerSendTextMessage(cid,22,"You have found a Sprite Wand")
   			doPlayerAddItem(cid,2452,1)
   			setPlayerStorageValue(cid,6406,1)
   		else
   			doPlayerSendTextMessage(cid,22,"It is empty.")
   		end
   	elseif item.uid == 6504 then
   		queststatus = getPlayerStorageValue(cid,6504)
   		if queststatus == -1 then
   			doPlayerSendTextMessage(cid,22,"You have found a Ice Rapier")
   			doPlayerAddItem(cid,2396,1)
   			setPlayerStorageValue(cid,6406,1)
   		else
   			doPlayerSendTextMessage(cid,22,"It is empty.")
   		end
   	elseif item.uid == 6505 then
   		queststatus = getPlayerStorageValue(cid,6505)
   		if queststatus == -1 then
   			doPlayerSendTextMessage(cid,22,"You have found Crystal Arrow")
   			doPlayerAddItem(cid,2352,1)
   			setPlayerStorageValue(cid,6406,1)
   		else
   			doPlayerSendTextMessage(cid,22,"It is empty.")
   		end
	else
		return 0
   	end

   	return 1
end