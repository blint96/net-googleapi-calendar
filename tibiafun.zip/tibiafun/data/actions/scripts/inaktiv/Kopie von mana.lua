
function onUse(cid, item, frompos, item2, topos)
mag = getPlayerMagLevel(cid)
if mag >= 50 then
doPlayerSay(cid,"Ahhh.. Mana Rune",16)
doPlayerAddMana(cid, 1000)
if item.type > 1 then
doChangeTypeItem(item.uid,item.type-1)
else
doRemoveItem(item.uid,1)
end
else
doSendMagicEffect(frompos,2)
doPlayerSendCancel(cid,"You need magic level 50 to use this rune...")
end
return 1
end