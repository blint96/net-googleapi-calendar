function onUse(cid, item, frompos, item, topos)

    storeitemtime	 = 401 -- Storage value where last fishing time is saved
   -- storeofitemuse		 = 402 -- Storage value where amount of rod uses is saved
    itembreak		 = 1000 -- Amount of times player can use rod before it break
    itemexhaust	 = 0 -- Time in seconds for exhausted
    --getitemid		 = 2744      -- Enter the itemid of a fish (useless)
    --makeritemid	 = 2376 -- Enter the itemid of a fishing rod (useless)

    theTime = os.time()
    oldTime = getPlayerStorageValue(cid, storeitemtime)
    if (oldTime == nil or oldTime < 1 or os.difftime(theTime, oldTime) < 0) then
        oldTime = 1
    end
    
    diffTime = os.difftime(theTime, oldTime)
    
    if (itemexhaust == nil or itemexhaust < 0) then
        itemexhaust = 0
    end
    
    if (diffTime >= itemexhaust) then
        setPlayerStorageValue(cid, storeitemtime, theTime) 
        itemuses = getPlayerStorageValue(cid, storeofitemuse)
       -- itemuses = itemuses + 1
        
       -- if (itemuses >= itembreak) then
           -- doRemoveItem(item.uid, item.type)
           -- doPlayerSendTextMessage(cid, 20, "Your rod broke due to over use.")
           -- itemuses = 0
           -- doSendMagicEffect(getPlayerPosition(cid), 2)
       -- end
       -- setPlayerStorageValue(cid, storeofitemuse, itemuses)
        
        if (item.itemid >= 1285 and item.itemid <= 1306) or (item.itemid >= 4471 and item.itemid <= 4513) then
		    setPlayerStorageValue(cid, storeitemtime, theTime)
            skill_level = getPlayerSkill(cid, 0)
            random_number = math.random(1, (120+skill_level/10))
            doSendMagicEffect(topos, 3)
            
            if random_number <= skill_level then
                catchtype = math.random(1, 2) -- chance /4 damit kann man die erfolgschance stark �ndern!

                if (catchtype == 1) then
					doSendMagicEffect(topos,12)
                         if (item.itemid >= 1285 and item.itemid <= 1306) or (item.itemid >= 4471 and item.itemid <= 4513) then	
rand = math.random(1,2000)
if (rand >= 1 and rand <= 20) then
doPlayerSendTextMessage(cid,22,"A stone golem came out of the pile of rocks!")
doSummonCreature("Stone Golem", topos)

elseif (rand >= 21 and rand <= 29) then
doPlayerSendTextMessage(cid,22,"A weak troll has appeared from the pile of rocks!")
doSummonCreature("Troll", topos)

elseif (rand >= 30 and rand <= 35) then
doPlayerSendTextMessage(cid,22,"You have found a golden nugget.")              
doPlayerAddItem(cid,2157,1)  

elseif (rand >= 36 and rand <= 49) then
doPlayerSendTextMessage(cid,22,"A fierce elite dwarf guard came out of the pile of rocks!")
doSummonCreature("Elite Dwarf Guard", topos)

elseif (rand >= 50 and rand <= 59) then
doPlayerSendTextMessage(cid,22,"A weak troll has appeared from the pile of rocks!")
doSummonCreature("Troll", topos)

elseif (rand >= 60 and rand <= 79) then
doPlayerSendTextMessage(cid,22,"A elite dwarf soldier came out of the pile of rocks!")
doSummonCreature("Elite Dwarf Soldier", topos)

elseif (rand >= 79 and rand <= 89) then
doRemoveItem(item.uid,1)
doSendMagicEffect(topos,2)
doPlayerSendTextMessage(cid,22,"Your pick has been heavily damaged and broke...")

elseif (rand >= 90 and rand <= 199) then
doPlayerSendTextMessage(cid,22,"A fierce elite dwarf came out of the pile of rocks!")
doSummonCreature("Elite Dwarf", topos)

elseif (rand >= 200 and rand <= 499) then
doPlayerSendTextMessage(cid,22,"You have found a ruby.")
doPlayerAddItem(cid,2147,1)
					
elseif (rand >= 500 and rand <= 1400) then
rand1 = math.random(2,8)
doPlayerSendTextMessage(cid,22,"You have found "..rand1.." platinum pieces.")
doPlayerAddItem(cid,2152,rand1)
				
elseif (rand >=1401 and rand <= 1600) then
rand2 = math.random(150,590)
doPlayerAddHealth(cid,-rand2)
doPlayerSendTextMessage(cid,22,"You lost "..rand2.." hitpoints due to exhaustion of mining.")				

elseif (rand >=1601 and rand <= 1639) then			            
doPlayerSendTextMessage(cid,22,"You have found a diamond.")
doPlayerAddItem(cid,2145,1)

elseif (rand >=1640 and rand <= 1669) then			            
doPlayerSendTextMessage(cid,22,"You have found a sapphire.")
doPlayerAddItem(cid,2146,1)

elseif (rand >=1670 and rand <= 1699) then			            
doPlayerSendTextMessage(cid,22,"You have found a emerald.")
doPlayerAddItem(cid,2149,1)

elseif (rand >=1700 and rand <= 1729) then			            
doPlayerSendTextMessage(cid,22,"You have found a amethyst.")
doPlayerAddItem(cid,2150,1)

elseif (rand >=1730 and rand <= 1740) then			            
doPlayerSendTextMessage(cid,22,"You have found a crystal coint.")
doPlayerAddItem(cid,2160,1)

elseif (rand >=1741 and rand <= 1789) then			            
doPlayerSendTextMessage(cid,22,"You have found a violet gem.")
doPlayerAddItem(cid,2153,1)

elseif (rand >=1790 and rand <= 1830) then			            
doPlayerSendTextMessage(cid,22,"You have found a green gem.")
doPlayerAddItem(cid,2155,1)

elseif (rand >=1831 and rand <= 1870) then			            
doPlayerSendTextMessage(cid,22,"You have found a red gem.")
doPlayerAddItem(cid,2156,1)

elseif (rand >=1871 and rand <= 1910) then			            
doPlayerSendTextMessage(cid,22,"You have found a yellow gem.")
doPlayerAddItem(cid,2154,1)

elseif (rand >= 1911 and rand <= 1989) then	
rand3 = math.random(10,30)		            
doPlayerSendTextMessage(cid,22,"You have found "..rand3.." platinum coins.")
doPlayerAddItem(cid,2152,rand4)

elseif (rand >= 1990 and rand <= 2000) then
rand4 = math.random(1900,2500)
doPlayerSendTextMessage(cid,22,"Earthquake. You have lost "..rand4.." hitpoints!")
doPlayerAddHealth(cid,-rand3)

													
						
					end
				end
            end
            doPlayerAddSkillTry(cid, 0, 1)
            
        else
            doPlayerSendCancel(cid, "You can not use this object.")
        end
    else
        doPlayerSendCancel(cid, "You are exhausted.")
    end
    return 1
end
end