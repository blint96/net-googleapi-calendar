-- Mining V2.6
-- Please understand this is more of a bug fix release
-- Coded by Roman, some credits to twiz for giving an example of his V1.0
function onUse(cid, item, frompos, item2, topos)

--if (exhaust(cid, 1000,zeit in sekunden) > 0) then 
rand2 = math.random(2,4)
rand3 = math.random(100,1000)

    if (exhaust(cid, 1000, rand2) > 0) then
Level = getPlayerLevel(cid)
ClubSkill = getPlayerSkill(cid,1)

if item2.actionid == 7575 and         -- set the action id of rocks
Level >= 10   -- set the level requirement to be able to mine
and
ClubSkill >= 10  -- set the club skill requirement to be able to mine
then 
rand = math.random(1,2000)
if rand < 20 then
doPlayerSendTextMessage(cid,22,"A stone golem came out of the pile of rocks!")
doSummonCreature("Stone Golem", topos)             
elseif rand == 1300 then
doPlayerSendTextMessage(cid,22,"You have found a golden nugget.")              
doPlayerAddItem(cid,2157,1)                
elseif rand > 1995 then
doPlayerSendTextMessage(cid,22,"You have found a diamond.")
doPlayerAddItem(cid,2145,1)
elseif rand >500 and rand <800 then
doPlayerAddItem(cid,2152,7)
elseif rand >700 and rand <1000 then
doPlayerAddItem(cid,2152,6)
elseif rand >1000 and rand <1300 then
doPlayerAddItem(cid,2152,4)
elseif rand >300 and rand <600 then
doPlayerAddItem(cid,2152,5)
elseif rand >1500 and rand <1800 then
doPlayerAddItem(cid,2152,3)
elseif rand >1100 and rand <1400 then
doPlayerAddItem(cid,2152,8)
elseif rand >800 and rand <1100 then
doPlayerAddHealth(cid,-rand3)
doPlayerSendTextMessage(cid,22,"You lost "..rand3.." hitpoints due to exhaustion of mining.")
elseif rand >500 and rand <800 then
doPlayerSendTextMessage(cid,22,"You have found a ruby.")
doPlayerAddItem(cid,2147,1)
elseif rand >550 and rand <800 then
doPlayerSendTextMessage(cid,22,"A fierce dwarf came out of the pile of rocks!")
doSummonCreature("Dwarf", topos)
elseif rand == 40 then
doPlayerSendTextMessage(cid,22,"A fierce dwarf guard came out of the pile of rocks!")
doSummonCreature("Dwarf Guard", topos)
elseif rand == 20 then
doPlayerSendTextMessage(cid,22,"A weak troll has appeared from the pile of rocks!")
doSummonCreature("Troll", topos)
elseif rand >2000 then
doPlayerSendTextMessage(cid,22,"Earthquake. You have lost "..rand3.." hitpoints!")
doPlayerAddHealth(cid,-rand3)
elseif rand == 100 and rand <140 then
doPlayerSendTextMessage(cid,22,"A weak troll has appeared from the pile of rocks!")
doSummonCreature("Troll", topos)
elseif rand == 200 then
doPlayerSendTextMessage(cid,22,"A dwarf soldier came out of the pile of rocks!")
doSummonCreature("Dwarf Soldier", topos)
elseif rand >= 105 and rand <150 then
    doRemoveItem(item.uid,1)
  doSendMagicEffect(topos,2)
doPlayerSendTextMessage(cid,22,"Your pick has been heavily damaged and broke...")
end
doSendMagicEffect(topos,3)
doPlayerAddSkillTry(cid,1,100)
doPlayerSay(cid,"Mining!",1)
else
 doPlayerSendCancel(cid,"You either are not mining on the specific rock or you do not have the required level or club skill to mine.")

end
else 
doPlayerSendCancel(cid, "You are exhausted.")
end
return 1
end