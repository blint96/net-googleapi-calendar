
function onUse(cid, item, frompos, item2, topos)

   	if item.uid == 6613 then
   		queststatus = getPlayerStorageValue(cid,6613)
   		if queststatus == -1 then
   			doPlayerSendTextMessage(cid,22,"You have found a Golden mace")
   			doPlayerAddItem(cid,2437,1)
   			setPlayerStorageValue(cid,6616,1)
   		else
   			doPlayerSendTextMessage(cid,22,"It is empty.")
   		end
   	elseif item.uid == 6614 then
   		queststatus = getPlayerStorageValue(cid,6614)
   		if queststatus == -1 then
   			doPlayerSendTextMessage(cid,22,"You have found a native armor")
   			doPlayerAddItem(cid,2508,1)
   			setPlayerStorageValue(cid,6616,1)
   		else
   			doPlayerSendTextMessage(cid,22,"It is empty.")
   		end
   	elseif item.uid == 6615 then
   		queststatus = getPlayerStorageValue(cid,6615)
   		if queststatus == -1 then
   			doPlayerSendTextMessage(cid,22,"You have found an Excalibur")
   			doPlayerAddItem(cid,2408,1)
   			setPlayerStorageValue(cid,6616,1)
   		else
   			doPlayerSendTextMessage(cid,22,"It is empty.")
   		end
	else
		return 0
   	end

   	return 1
end