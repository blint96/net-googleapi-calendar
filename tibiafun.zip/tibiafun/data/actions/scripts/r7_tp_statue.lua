function onUse(cid, item, frompos, item2, topos)

-- start pos

playerpos1 = {x=258, y=881, z=4, stackpos=253}
player1 = getThingfromPos(playerpos1)
		
playerpos2 = {x=258, y=882, z=4, stackpos=253}
player2 = getThingfromPos(playerpos2)

playerpos3 = {x=257, y=882, z=4, stackpos=253}
player3 = getThingfromPos(playerpos3)

-- pos after getting tped

nplayerpos1 = {x=264, y=890, z=2, stackpos=253}
nplayer1 = getThingfromPos(nplayerpos1)
		
nplayerpos2 = {x=256, y=885, z=2, stackpos=253}
nplayer2 = getThingfromPos(nplayerpos2)

nplayerpos3 = {x=260, y=886, z=2, stackpos=253}
nplayer3 = getThingfromPos(nplayerpos3)

-- check if stairs are there

cobrapos = {x=260, y=882, z=2, stackpos=1}
cobra = getThingfromPos(cobrapos)

stairspos = {x=261, y=892, z=2, stackpos=1}
stairs = getThingfromPos(stairspos)



if item.itemid == 3728 and item.uid == 9018 and player1.itemid > 0 and cobra.itemid == 1504 then 
doPlayerSendTextMessage(cid,24,"Wild Jumping around may cause Debug!") 


doTeleportThing(player1.uid,nplayerpos1)  
--doTransformItem(cobra.uid,cobra.itemid-1)
--doCreateItem(3688,1,stairspos) 
doSendMagicEffect(nplayerpos1,10)





elseif item.itemid == 3728 and item.uid == 9018 and player1.itemid > 0 and cobra.itemid == 1495 then 

doPlayerSendTextMessage(cid,22,"Wild Jumping around may cause Debug!!") 
doTeleportThing(player1.uid,nplayerpos1)

doTransformItem(cobra.uid,1504)
doRemoveItem(stairs.uid,1)


doSendMagicEffect(nplayerpos1,23)


elseif item.itemid == 3728 and item.uid == 9018 and player2.itemid > 0 and cobra.itemid == 1504 then 

doPlayerSendTextMessage(cid,24,"Wild Jumping around may cause Debug!") 
doTeleportThing(player2.uid,nplayerpos2)
--doTransformItem(cobra.uid,cobra.itemid-1)
--doCreateItem(3688,1,stairspos)

doSendMagicEffect(nplayerpos2,23)

elseif item.itemid == 3728 and item.uid == 9018 and player2.itemid > 0 and cobra.itemid == 1495 then 

doPlayerSendTextMessage(cid,24,"Wild Jumping around may cause Debug!") 
doTeleportThing(player2.uid,nplayerpos2)

doTransformItem(cobra.uid,1504)
doRemoveItem(stairs.uid,1)


doSendMagicEffect(nplayerpos2,23)


elseif item.itemid == 3728 and item.uid == 9018 and player3.itemid > 0 and cobra.itemid == 1504 then 

doPlayerSendTextMessage(cid,24,"Wild Jumping around may cause Debug!") 
doTeleportThing(player3.uid,nplayerpos3)
--doTransformItem(cobra.uid,cobra.itemid-1)
--doCreateItem(3688,1,stairspos)

doSendMagicEffect(nplayerpos3,23)

elseif item.itemid == 3728 and item.uid == 9018 and player3.itemid > 0 and cobra.itemid == 1495 then 

doPlayerSendTextMessage(cid,24,"Wild Jumping around may cause Debug!") 
doTeleportThing(player3.uid,nplayerpos3)

doTransformItem(cobra.uid,1504)
doRemoveItem(stairs.uid,1)


doSendMagicEffect(nplayerpos3,23)



else
doPlayerSendTextMessage(cid,24,"You are not staying on a correct position.") 


end


return 1

end

