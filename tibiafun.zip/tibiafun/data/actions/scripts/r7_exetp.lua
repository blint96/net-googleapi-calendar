-- pvp arena lever


function onUse(cid, item, frompos, item2, topos)
playerset1 = 0
playerset2 = 0
playerset3 = 0

player1 = 0
player2 = 0
player3 = 0

if item.uid == 7001 and item.itemid == 1945 then

		
		player1pos = {x=167, y=64, z=5, stackpos=253}
		player1 = getThingfromPos(player1pos)
		playerset1 = 1
		
		player2pos = {x=168, y=64, z=5, stackpos=253}
		player2 = getThingfromPos(player2pos)
		playerset2 = 1
		
		player3pos = {x=169, y=64, z=5, stackpos=253}
		player3 = getThingfromPos(player3pos)
		playerset3 = 1
			


	
	if playerset1 == 1 then
		nplayer1pos = {x=173, y=67, z=5}
		doSendMagicEffect(player1pos,2)
		doTeleportThing(player1.uid,nplayer1pos)
		doSendMagicEffect(nplayer1pos,10)
		doPlayerSendTextMessage(player1.uid,18,"Congratulation, you are ready for the next Challenge!")
	end
	
	if playerset2 == 1 then
		nplayer2pos = {x=173, y=68, z=5}
		doSendMagicEffect(player2pos,2)
		doTeleportThing(player2.uid,nplayer2pos)
		doSendMagicEffect(nplayer2pos,10)
		doPlayerSendTextMessage(player2.uid,18,"FIGHT!")
	end
	
	if playerset3 == 1 then
		nplayer3pos = {x=173, y=69, z=5}
		doSendMagicEffect(player3pos,2)
		doTeleportThing(player3.uid,nplayer3pos)
		doSendMagicEffect(nplayer3pos,10)
		doPlayerSendTextMessage(player3.uid,18,"FIGHT!")
	end
	



	
else
	
return 0
end

return 1
end
end	