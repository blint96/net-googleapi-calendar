function onUse(cid, item, frompos, item2, topos)

sewerpos1 = {x=260, y=882, z=3, stackpos=1} 
sewer1 = getThingfromPos(sewerpos1)  

sewerpos2 = {x=262, y=883, z=3, stackpos=1} 
sewer2 = getThingfromPos(sewerpos2)  

sewerpos3 = {x=256, y=884, z=3, stackpos=1} 
sewer3 = getThingfromPos(sewerpos3)  

sewerpos4 = {x=259, y=884, z=3, stackpos=1} 
sewer4 = getThingfromPos(sewerpos4)  

sewerpos5 = {x=261, y=884, z=3, stackpos=1} 
sewer5 = getThingfromPos(sewerpos5)  

sewerpos6 = {x=264, y=885, z=3, stackpos=1} 
sewer6 = getThingfromPos(sewerpos6)  

sewerpos7 = {x=262, y=885, z=3, stackpos=1} 
sewer7 = getThingfromPos(sewerpos7)  

sewerpos8 = {x=264, y=887, z=3, stackpos=1} 
sewer8 = getThingfromPos(sewerpos8)  

sewerpos9 = {x=257, y=886, z=3, stackpos=1} 
sewer9 = getThingfromPos(sewerpos9)  

sewerpos10 = {x=254, y=886, z=3, stackpos=1} 
sewer10 = getThingfromPos(sewerpos10)  

sewerpos11 = {x=255, y=888, z=3, stackpos=1} 
sewer11 = getThingfromPos(sewerpos11)  

sewerpos12 = {x=257, y=888, z=3, stackpos=1} 
sewer12 = getThingfromPos(sewerpos12)  

sewerpos13 = {x=262, y=888, z=3, stackpos=1} 
sewer13 = getThingfromPos(sewerpos13)  

sewerpos14 = {x=258, y=890, z=3, stackpos=1} 
sewer14 = getThingfromPos(sewerpos14)  

sewerpos15 = {x=260, y=891, z=3, stackpos=1} 
sewer15 = getThingfromPos(sewerpos15)  




if item.itemid == 3943 and item.uid == 9506 then 

doTransformItem(item.uid,item.itemid+1)
doPlayerSendTextMessage(cid,22,"Two brings luck. Four mostly bad luck. And zero is your Death!") 
 
doCreateItem(430,1,sewerpos1) 
doCreateItem(430,1,sewerpos2) 
doCreateItem(430,1,sewerpos3) 
doCreateItem(430,1,sewerpos4) 
doCreateItem(430,1,sewerpos5) 
doCreateItem(430,1,sewerpos6) 
doCreateItem(430,1,sewerpos7) 
doCreateItem(430,1,sewerpos8) 
doCreateItem(430,1,sewerpos9) 
doCreateItem(430,1,sewerpos10) 
doCreateItem(430,1,sewerpos11) 
doCreateItem(430,1,sewerpos12) 
doCreateItem(430,1,sewerpos13) 
doCreateItem(430,1,sewerpos14) 
doCreateItem(430,1,sewerpos15) 

doSendMagicEffect(sewerpos1, 2)
doSendMagicEffect(sewerpos2, 2)
doSendMagicEffect(sewerpos3, 2)
doSendMagicEffect(sewerpos4, 2)
doSendMagicEffect(sewerpos5, 2)
doSendMagicEffect(sewerpos6, 2)
doSendMagicEffect(sewerpos7, 2)
doSendMagicEffect(sewerpos8, 2)
doSendMagicEffect(sewerpos9, 2)
doSendMagicEffect(sewerpos10, 2)
doSendMagicEffect(sewerpos11, 2)
doSendMagicEffect(sewerpos12, 2)
doSendMagicEffect(sewerpos13, 2)
doSendMagicEffect(sewerpos14, 2)
doSendMagicEffect(sewerpos15, 2)



elseif item.uid == 9506 and item.itemid == 3944 then
doTransformItem(item.uid,item.itemid-1)

doRemoveItem(sewer1.uid,1)
doRemoveItem(sewer2.uid,1)
doRemoveItem(sewer3.uid,1)
doRemoveItem(sewer4.uid,1)
doRemoveItem(sewer5.uid,1)
doRemoveItem(sewer6.uid,1)
doRemoveItem(sewer7.uid,1)
doRemoveItem(sewer8.uid,1)
doRemoveItem(sewer9.uid,1)
doRemoveItem(sewer10.uid,1)
doRemoveItem(sewer11.uid,1)
doRemoveItem(sewer12.uid,1)
doRemoveItem(sewer13.uid,1)
doRemoveItem(sewer14.uid,1)
doRemoveItem(sewer15.uid,1)

doSendMagicEffect(sewerpos1, 2)
doSendMagicEffect(sewerpos2, 2)
doSendMagicEffect(sewerpos3, 2)
doSendMagicEffect(sewerpos4, 2)
doSendMagicEffect(sewerpos5, 2)
doSendMagicEffect(sewerpos6, 2)
doSendMagicEffect(sewerpos7, 2)
doSendMagicEffect(sewerpos8, 2)
doSendMagicEffect(sewerpos9, 2)
doSendMagicEffect(sewerpos10, 2)
doSendMagicEffect(sewerpos11, 2)
doSendMagicEffect(sewerpos12, 2)
doSendMagicEffect(sewerpos13, 2)
doSendMagicEffect(sewerpos14, 2)
doSendMagicEffect(sewerpos15, 2)


else
doPlayerSendTextMessage(cid,22,"Something is wrong. Mr. Else here") 

end


   		
return 1

end

