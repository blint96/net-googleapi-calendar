function onUse(cid, item, frompos, item2, topos)

     -- set there positions of switches
    firstlever_pos = {x=227, y=642, z=13, stackpos=1} -- 9030
    firstlever = getThingfromPos(firstlever_pos)
	
	secondlever_pos = {x=228, y=648, z=13, stackpos=1} -- 9031
    secondlever = getThingfromPos(secondlever_pos)
	
	thirdlever_pos = {x=227, y=654, z=13, stackpos=1} -- 9032
    thirdlever = getThingfromPos(thirdlever_pos)
	
	forthlever_pos = {x=246, y=641, z=13, stackpos=1} -- 9033
    forthlever = getThingfromPos(forthlever_pos)
	
	fifthlever_pos = {x=247, y=650, z=13, stackpos=1} -- 9034
    fifthlever = getThingfromPos(fifthlever_pos)
	
	sixthlever_pos = {x=239, y=654, z=13, stackpos=1} -- 9035
    sixthlever = getThingfromPos(sixthlever_pos)
	

	
	-- goal check
	if item.uid == 9037 and item.itemid == 3812 and firstlever.itemid == 1946 and secondlever.itemid == 1946 and thirdlever.itemid == 1946 and forthlever.itemid == 1945 and fifthlever.itemid == 1945 and sixthlever.itemid == 1946 then
	
	--doTransformItem(item.uid,1946)
	doPlayerSendTextMessage(cid,22,"GOAL! GOAL! GOAL!") 
	setPlayerStorageValue(cid,9038,1)
	doTransformItem(firstlever.uid,1945) -- 0
	doTransformItem(secondlever.uid,1946) -- 1
	doTransformItem(thirdlever.uid,1945) -- 0
	doTransformItem(forthlever.uid,1946) -- 1
	doTransformItem(fifthlever.uid,1946) -- 1
	doTransformItem(sixthlever.uid,1945) -- 0
	
    
	
	

	
	
	else
	doPlayerSendTextMessage(cid,22,"Levers in wrong order. Reseting...") 
	doTransformItem(firstlever.uid,1945) -- 0
	doTransformItem(secondlever.uid,1946) -- 1
	doTransformItem(thirdlever.uid,1945) -- 0
	doTransformItem(forthlever.uid,1946) -- 1
	doTransformItem(fifthlever.uid,1946) -- 1
	doTransformItem(sixthlever.uid,1945) -- 0
	



end


return 1

end



