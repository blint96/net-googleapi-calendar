function onUse(cid, item, frompos, item2, topos)

     -- set there positions of switches
    --firstlever_pos = {x=158, y=49, z=8, stackpos=1} -- 9030
    --firstlever = getThingfromPos(firstlever_pos)
	
	--secondlever_pos = {x=158, y=50, z=8, stackpos=1} -- 9031
    --secondlever = getThingfromPos(secondlever_pos)
	
	--thirdlever_pos = {x=158, y=51, z=8, stackpos=1} -- 9032
    --thirdlever = getThingfromPos(thirdlever_pos)
	
	--forthlever_pos = {x=161, y=49, z=8, stackpos=1} -- 9033
    --forthlever = getThingfromPos(forthlever_pos)
	
	fifthlever_pos = {x=247, y=650, z=13, stackpos=1} -- 9034
    fifthlever = getThingfromPos(fifthlever_pos)
	
	sixthlever_pos = {x=239, y=654, z=13, stackpos=1} -- 9035
    sixthlever = getThingfromPos(sixthlever_pos)
	


	
	-- case 1
   	if item.itemid == 1946 and item.uid == 9034 and fifthlever.itemid == 1946 then
	 
	doTransformItem(item.uid,1945)
	doPlayerSendTextMessage(cid,22,"Lever NW: CASE 1 WORKS!") 
	doTransformItem(fifthlever.uid,1945)
	
	elseif item.itemid == 1946 and item.uid == 9034 and fifthlever.itemid == 1945 then
	 
	doTransformItem(item.uid,1945)
	doPlayerSendTextMessage(cid,22,"Lever NW: CASE 4 WORKS") 
	
	elseif item.itemid == 1945 and item.uid == 9034 and sixthlever.itemid == 1946 then
	 
	doTransformItem(item.uid,1946)
	doPlayerSendTextMessage(cid,22,"Lever NW: CASE 3 WORKS!") 
	doTransformItem(sixthlever.uid,1945)
	
	elseif item.itemid == 1945 and item.uid == 9034 and sixthlever.itemid == 1945 then
	 
	doTransformItem(item.uid,1946)
	doPlayerSendTextMessage(cid,22,"Lever NW: CASE 4 WORKS") 
	

	
	
	else
doPlayerSendTextMessage(cid,22,"Hello.I am ELSE") 


end


return 1

end



