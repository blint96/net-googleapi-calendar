-- Door_locked.lua
-- Created by GriZzm0.
function onUse(cid, item, frompos, item2, topos)
	doPlayerSendTextMessage(cid,22,"It is locked.")
	return 1
end