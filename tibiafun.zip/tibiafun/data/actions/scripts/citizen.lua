-- Stones of Citizenship by Talaturen
function onUse(cid, item, frompos, item2, topos)
citypos = {x=160, y=53, z=6} 	-- temple respawn 1st city
nayelipos = {x=268, y=245, z=7} 	-- temple respawn 2nd city
bannaloniapos = {x=706, y=745, z=7}   	-- temple respawn 3rd city
okenpos = {x=247, y=163, z=7}   	-- temple respawn 4rd city
infereslapos = {x=80, y=149, z=7}   	-- temple respawn 4rd city
gottipos = {x=618, y=620, z=7}   	-- temple respawn 4rd city
junglepos = {x=335, y=84, z=7}   	-- temple respawn 4rd city
hoganaspos = {x=128, y=422, z=7}   	-- temple respawn 4rd city
camelotpos = {x=724, y=588, z=7} 	-- temple respawn 5th city
playerpos = getPlayerPosition(cid)
playerstor = getPlayerStorageValue(cid,8000)
if item.uid == 8004 and playerstor ~= 1 then				-- 1st city fountain uniqueid
doPlayerSetMasterPos(cid,citypos)
setPlayerStorageValue(cid,8000,1)
doSendMagicEffect(playerpos,12)
doPlayerSendTextMessage(cid,22,"You have been blessed and now you are a citizen of City.")
else doPlayerSendCancel(cid,"You have been already blessed.")
end
if item.uid == 8001 and playerstor ~= 2 then				-- 2nd city fountain uniqueid
doPlayerSetMasterPos(cid,nayelipos)
setPlayerStorageValue(cid,8000,2)
doSendMagicEffect(playerpos,12)
doPlayerSendTextMessage(cid,22,"You have been blessed and now you are a citizen of Nayeli.")
else doPlayerSendCancel(cid,"You have been already blessed.")
end
if item.uid == 8002 and playerstor ~= 3 then				-- 3rd city fountain uniqueid
doPlayerSetMasterPos(cid,bannaloniapos)
setPlayerStorageValue(cid,8000,3)
doSendMagicEffect(playerpos,12)
doPlayerSendTextMessage(cid,22,"You have been blessed and now you are a citizen of Bannalonia City.")
else doPlayerSendCancel(cid,"You have been already blessed.")
end
if item.uid == 8010 and playerstor ~= 4 then				-- 3rd city fountain uniqueid
doPlayerSetMasterPos(cid,okenpos)
setPlayerStorageValue(cid,8000,4)
doSendMagicEffect(playerpos,12)
doPlayerSendTextMessage(cid,22,"You have been blessed and now you are a citizen of Oken.")
else doPlayerSendCancel(cid,"You have been already blessed.")
end
if item.uid == 8006 and playerstor ~= 5 then				-- 3rd city fountain uniqueid
doPlayerSetMasterPos(cid,infereslapos)
setPlayerStorageValue(cid,8000,5)
doSendMagicEffect(playerpos,12)
doPlayerSendTextMessage(cid,22,"You have been blessed and now you are a citizen of Inferesla.")
else doPlayerSendCancel(cid,"You have been already blessed.")
end
if item.uid == 8007 and playerstor ~= 6 then				-- 3rd city fountain uniqueid
doPlayerSetMasterPos(cid,gottipos)
setPlayerStorageValue(cid,8000,6)
doSendMagicEffect(playerpos,12)
doPlayerSendTextMessage(cid,22,"You have been blessed and now you are a citizen of Gotti.")
else doPlayerSendCancel(cid,"You have been already blessed.")
end
if item.uid == 8008 and playerstor ~= 7 then				-- 3rd city fountain uniqueid
doPlayerSetMasterPos(cid,junglepos)
setPlayerStorageValue(cid,8000,7)
doSendMagicEffect(playerpos,12)
doPlayerSendTextMessage(cid,22,"You have been blessed and now you are a citizen of Jungle.")
else doPlayerSendCancel(cid,"You have been already blessed.")
end
if item.uid == 8009 and playerstor ~= 8 then				-- 3rd city fountain uniqueid
doPlayerSetMasterPos(cid,hoganaspos)
setPlayerStorageValue(cid,8000,8)
doSendMagicEffect(playerpos,12)
doPlayerSendTextMessage(cid,22,"You have been blessed and now you are a citizen of Hoganas.")
else doPlayerSendCancel(cid,"You have been already blessed.")
end
return 1
end