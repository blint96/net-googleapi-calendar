 
--Make flour to dough by Darkpower--
function onUse(cid, item, frompos, item2, topos)
if item2.itemid == 0 then
return 0
end
if item2.itemid == 2005 or item2.itemid == 2006 or item2.itemid == 1775 then
 if item2.type == 1 then
   doRemoveItem(item.uid,1)
   doPlayerAddItem(cid,2693,1)
   doChangeTypeItem(item2.uid,0)
 else
   return 0
 end
   return 1
end
end