-- pvp arena lever


function onUse(cid, item, frompos, item2, topos)
arenalevel = 150
playerset1 = 0
playerset2 = 0
playerset3 = 0
playerset4 = 0
playerset5 = 0
playerset6 = 0
player1 = 0
player2 = 0
player3 = 0
player4 = 0
player5 = 0
player6 = 0
if item.uid == 7001 and item.itemid == 1945 then

		doTransformItem(item.uid,item.itemid+1)
		
		player1pos = {x=167, y=64, z=5, stackpos=253}
		player1 = getThingfromPos(player1pos)
		
		player2pos = {x=168, y=64, z=5, stackpos=253}
		player2 = getThingfromPos(player2pos)
		
		player3pos = {x=169, y=64, z=5, stackpos=253}
		player3 = getThingfromPos(player3pos)
		
		player4pos = {x=169, y=66, z=5, stackpos=253}
		player4 = getThingfromPos(player4pos)
  
		player5pos = {x=168, y=66, z=5, stackpos=253}
		player5 = getThingfromPos(player5pos)
		
		player6pos = {x=167, y=66, z=5, stackpos=253}
		player6 = getThingfromPos(player6pos)
		
		if player1.itemid > 0 then
			player1level = getPlayerLevel(player1.uid)
			playerset1 = 1
			if (player1level < arenalevel) then
				playerset1 = 0
				doPlayerSendTextMessage(player1.uid,18,"Your level is too low ("..arenalevel.." required)")
			end
		end
		
		if player2.itemid > 0 then
			player2level = getPlayerLevel(player2.uid)
			playerset2 = 1
			if (player2level < arenalevel) then
				playerset2 = 0
				doPlayerSendTextMessage(player2.uid,18,"Your level is too low ("..arenalevel.." required)")
			end
		end
		
		if player3.itemid > 0 then
			player3level = getPlayerLevel(player3.uid)
			playerset3 = 1
			if (player3level < arenalevel) then
				playerset3 = 0
				doPlayerSendTextMessage(player3.uid,18,"Your level is too low ("..arenalevel.." required)")
			end
		end
		
		if player4.itemid > 0 then
			player4level = getPlayerLevel(player4.uid)
			playerset4 = 1
			if (player4level < arenalevel) then
				playerset4 = 0
				doPlayerSendTextMessage(player4.uid,18,"Your level is too low ("..arenalevel.." required)")
			end
		end

		if player5.itemid > 0 then
			player5level = getPlayerLevel(player5.uid)
			playerset5 = 1
			if (player5level < arenalevel) then
				playerset5 = 0
				doPlayerSendTextMessage(player5.uid,18,"Your level is too low ("..arenalevel.." required)")
			end
		end

		if player6.itemid > 0 then
			player6level = getPlayerLevel(player6.uid)
			playerset6 = 1
			if (player6level < arenalevel) then
				playerset6 = 0
				doPlayerSendTextMessage(player6.uid,18,"Your level is too low ("..arenalevel.." required)")
			end
		end
		
		for arenax = 173,184 do	
			for arenay = 65,71 do
				arenapos = {x=arenax, y=arenay, z=5, stackpos=253}
				arenacreature = getThingfromPos(arenapos)

				if arenacreature.itemid > 0 then
					doPlayerSendCancel(cid,"Wait for current duel to end.")
					return 1
				end
			end
		end
	
	if playerset1 + playerset2 + playerset3 + playerset4 + playerset5 + playerset6 >= 2 then
	if playerset1 == 1 then
		nplayer1pos = {x=173, y=67, z=5}
		doSendMagicEffect(player1pos,2)
		doTeleportThing(player1.uid,nplayer1pos)
		doSendMagicEffect(nplayer1pos,10)
		doPlayerSendTextMessage(player1.uid,18,"FIGHT!")
	end
	
	if playerset2 == 1 then
		nplayer2pos = {x=173, y=68, z=5}
		doSendMagicEffect(player2pos,2)
		doTeleportThing(player2.uid,nplayer2pos)
		doSendMagicEffect(nplayer2pos,10)
		doPlayerSendTextMessage(player2.uid,18,"FIGHT!")
	end
	
	if playerset3 == 1 then
		nplayer3pos = {x=173, y=69, z=5}
		doSendMagicEffect(player3pos,2)
		doTeleportThing(player3.uid,nplayer3pos)
		doSendMagicEffect(nplayer3pos,10)
		doPlayerSendTextMessage(player3.uid,18,"FIGHT!")
	end
	
	if playerset4 == 1 then
		nplayer4pos = {x=184, y=67, z=5}
		doSendMagicEffect(player4pos,2)
		doTeleportThing(player4.uid,nplayer4pos)
		doSendMagicEffect(nplayer4pos,10)
		doPlayerSendTextMessage(player4.uid,18,"FIGHT!")
	end

	if playerset5 == 1 then
		nplayer5pos = {x=184, y=68, z=5}
		doSendMagicEffect(player5pos,2)
		doTeleportThing(player5.uid,nplayer5pos)
		doSendMagicEffect(nplayer5pos,10)
		doPlayerSendTextMessage(player5.uid,18,"FIGHT!")
	end
	
	if playerset6 == 1 then
		nplayer6pos = {x=184, y=69, z=5}
		doSendMagicEffect(player6pos,2)
		doTeleportThing(player6.uid,nplayer6pos)
		doSendMagicEffect(nplayer6pos,10)
		doPlayerSendTextMessage(player6.uid,18,"FIGHT!")
	end
	
else
	
return 0
end

else
doTransformItem(item.uid,item.itemid-1)
doPlayerSendCancel(cid,"Only one fighter?")
return 1
end
end	