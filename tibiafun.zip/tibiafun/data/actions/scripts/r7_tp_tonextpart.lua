function onUse(cid, item, frompos, item2, topos)


playerpos = {x=260, y=890, z=0, stackpos=1}
player = getThingfromPos(playerpos)
		
corpsepos = {x=260, y=893, z=0, stackpos=1}
corpse = getThingfromPos(corpsepos)

done_bazir_tower = getPlayerStorageValue(cid,9021)


if item.itemid == 1945 and item.uid == 9020 and corpse.itemid == 2916 and done_bazir_tower == -1 and player.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"Congratulations. You finished the Illusion Tower. Talk to the guard if you want to return to the Main Hall") 

doTransformItem(item.uid,item.itemid+1)
setPlayerStorageValue(cid,9021,1)
doSendMagicEffect(playerpos,22)

elseif item.itemid == 1946 and item.uid == 9020 and corpse.itemid == 2916 and done_bazir_tower == -1 and player.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"Congratulations. You Finished the Illusion Tower . Talk to the guard if you want to return to the Main Hall.") 

doTransformItem(item.uid,item.itemid-1)
setPlayerStorageValue(cid,9021,1)
doSendMagicEffect(playerpos,22)



else
doPlayerSendTextMessage(cid,18,"Put the dead Bazir on a correct place. Keep in mind that your time is limited.") 


end


return 1

end


