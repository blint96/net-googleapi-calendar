function onUse(cid, item, frompos, item, topos)

    storeitemtime	 = 401 -- Storage value where last fishing time is saved
   -- storeofitemuse		 = 402 -- Storage value where amount of rod uses is saved
    itembreak		 = 1000 -- Amount of times player can use rod before it break
    itemexhaust	 = 1 -- Time in seconds for exhausted
    --getitemid		 = 2744      -- Enter the itemid of a fish (useless)
    --makeritemid	 = 2376 -- Enter the itemid of a fishing rod (useless)

    theTime = os.time()
    oldTime = getPlayerStorageValue(cid, storeitemtime)
    if (oldTime == nil or oldTime < 1 or os.difftime(theTime, oldTime) < 0) then
        oldTime = 1
    end
    
    diffTime = os.difftime(theTime, oldTime)
    
    if (itemexhaust == nil or itemexhaust < 0) then
        itemexhaust = 0
    end
    
    if (diffTime >= itemexhaust) then
        setPlayerStorageValue(cid, storeitemtime, theTime) 
        itemuses = getPlayerStorageValue(cid, storeofitemuse)
       -- itemuses = itemuses + 1
        
       -- if (itemuses >= itembreak) then
           -- doRemoveItem(item.uid, item.type)
           -- doPlayerSendTextMessage(cid, 20, "Your rod broke due to over use.")
           -- itemuses = 0
           -- doSendMagicEffect(getPlayerPosition(cid), 2)
       -- end
       -- setPlayerStorageValue(cid, storeofitemuse, itemuses)
        
        if item.itemid == 4006 or item.itemid == 2705 or item.itemid == 2701 or  item.itemid == 2703 or item.itemid == 4170 or item.itemid == 4171 or item.itemid == 4180 or item.itemid == 4181 or item.itemid == 4178 or item.itemid == 4179 or item.itemid == 2762 or item.itemid == 2763 or item.itemid == 2764 then
		    setPlayerStorageValue(cid, storeitemtime, theTime)
            skill_level = getPlayerSkill(cid, 0)
            random_number = math.random(1, (80+skill_level/10))
            doSendMagicEffect(topos, 3)
            
            if random_number <= skill_level then
                catchtype = math.random(1, 2) -- chance /4 damit kann man die erfolgschance stark �ndern!

                if (catchtype == 1) then
					doSendMagicEffect(topos,12)
					
                        if item.itemid == 4006 then
							doPlayerAddItem(cid, 2675, 1) -- orange tree and orange
						elseif item.itemid == 2705 then 
							doPlayerAddItem(cid, 2673, 1) -- pear tree and pear
						elseif item.itemid == 2701 then
							doPlayerAddItem(cid, 2679, 1) -- cherry tree and cherry
						elseif item.itemid == 2703 then
							doPlayerAddItem(cid, 2674, 1) -- apple tree and apple
							
						elseif item.itemid == 4170 then
							doPlayerAddItem(cid, 2792, 1) -- mushroom x3 dark mushroom
						elseif item.itemid == 4171 then
							doPlayerAddItem(cid, 2792, 1) -- mushroom x1 dark mushroom
							
						elseif item.itemid == 4189 then
							doPlayerAddItem(cid, 2793, 1) -- mushroom(braun) x3 mushroom
						elseif item.itemid == 4181 then
							doPlayerAddItem(cid, 2793, 1) -- mushroom(braun x1 mushroom						
							
						elseif item.itemid == 4178 then
							doPlayerAddItem(cid, 2794, 1) -- mushroom(hellbraun) x3 mushroom
						elseif item.itemid == 4179 then
							doPlayerAddItem(cid, 2794, 1) -- mushroom(hellbraun) x1 mushroom	
							
						elseif item.itemid == 2763 then
							doPlayerAddItem(cid, 2744, 1)	-- red rose bush and red rose								
						elseif item.itemid == 2764 then						
							doPlayerAddItem(cid, 2745, 1) -- blue rose bush and blue rose
						elseif item.itemid == 2762 then
							doPlayerAddItem(cid, 2746, 1)	-- yellow rose bush and yellow rose								
											
													
						end
				
				end
            end
            doPlayerAddSkillTry(cid, 0, 1)
            
        else
            doPlayerSendCancel(cid, "You can not use this object.")
        end
    else
        doPlayerSendCancel(cid, "You are exhausted.")
    end
    return 1
end