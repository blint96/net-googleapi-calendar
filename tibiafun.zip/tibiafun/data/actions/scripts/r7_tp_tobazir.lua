function onUse(cid, item, frompos, item2, topos)

-- start pos

playerpos1 = {x=259, y=881, z=0, stackpos=1}
player1 = getThingfromPos(playerpos1)
		

-- pos after getting tped

nplayerpos1 = {x=255, y=881, z=0, stackpos=1}
nplayer1 = getThingfromPos(nplayerpos1)
		
nplayerpos2 = {x=263, y=881, z=0, stackpos=1}
nplayer2 = getThingfromPos(nplayerpos2)

nplayerpos3 = {x=261, y=882, z=0, stackpos=1}
nplayer3 = getThingfromPos(nplayerpos3)

-- statues pos

statue1pos = {x=250, y=887, z=1, stackpos=1}
statue1 = getThingfromPos(statue1pos)

statue2pos = {x=260, y=897, z=1, stackpos=1}
statue2 = getThingfromPos(statue2pos)

statue3pos = {x=270, y=887, z=1, stackpos=1}
statue3 = getThingfromPos(statue3pos)

stairpos = {x=260, y=878, z=1, stackpos=1}
stair = getThingfromPos(stairpos)



----- case1: all statues are ON

if item.itemid == 3741 and item.uid == 9019 and getPlayerVocation(cid) == 1 and statue1.itemid == 1471 and statue2.itemid == 1468 and statue3.itemid == 1470 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 

doRemoveItem(stair.uid,1)
doTransformItem(statue1.uid,statue1.itemid-2)
doTransformItem(statue2.uid,statue2.itemid-2)
doTransformItem(statue3.uid,statue3.itemid-1)
doTeleportThing(player1.uid,nplayerpos1)  
doSendMagicEffect(nplayerpos1,10)

elseif item.itemid == 3741 and item.uid == 9019 and getPlayerVocation(cid) == 3 and statue1.itemid == 1471 and statue2.itemid == 1468 and statue3.itemid == 1470 and player1.itemid > 0 then
doPlayerSendTextMessage(cid,22,"You got teleported!") 

doTransformItem(statue1.uid,statue1.itemid-2)
doTransformItem(statue2.uid,statue2.itemid-2)
doTransformItem(statue3.uid,statue3.itemid-1)
doRemoveItem(stair.uid,1)
doTeleportThing(player1.uid,nplayerpos2)  
doSendMagicEffect(nplayerpos2,10)

elseif item.itemid == 3741 and item.uid == 9019 and getPlayerVocation(cid) == 4 and statue1.itemid == 1471 and statue2.itemid == 1468 and statue3.itemid == 1470 and player1.itemid > 0 then
doPlayerSendTextMessage(cid,22,"You got teleported!") 

doTransformItem(statue1.uid,statue1.itemid-2)
doTransformItem(statue2.uid,statue2.itemid-2)
doTransformItem(statue3.uid,statue3.itemid-1)
doRemoveItem(stair.uid,1)
doTeleportThing(player1.uid,nplayerpos3)  
doSendMagicEffect(nplayerpos3,10)


-------------------------------- case 4: ALL are OFF


elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1469 and statue2.itemid == 1466 and statue3.itemid == 1469 and getPlayerVocation(cid) == 1 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 

doRemoveItem(stair.uid,1)
doTeleportThing(player1.uid,nplayerpos1)  
doSendMagicEffect(nplayerpos1,10)

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1469 and statue2.itemid == 1466 and statue3.itemid == 1469 and getPlayerVocation(cid) == 3 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 


doRemoveItem(stair.uid,1)
doTeleportThing(player1.uid,nplayerpos2)  
doSendMagicEffect(nplayerpos2,10)

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1469 and statue2.itemid == 1466 and statue3.itemid == 1469 and getPlayerVocation(cid) == 4 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 

doRemoveItem(stair.uid,1)
doTeleportThing(player1.uid,nplayerpos3)  
doSendMagicEffect(nplayerpos3,10)

------------------------------------- case 5: statue 1 is ON

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1471 and statue2.itemid == 1466 and statue3.itemid == 1469 and getPlayerVocation(cid) == 1 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 

doRemoveItem(stair.uid,1)
doTransformItem(statue1.uid,statue1.itemid-2)
doTeleportThing(player1.uid,nplayerpos1)  
doSendMagicEffect(nplayerpos1,10)

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1471 and statue2.itemid == 1466 and statue3.itemid == 1469 and getPlayerVocation(cid) == 3 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 

doRemoveItem(stair.uid,1)
doTransformItem(statue1.uid,statue1.itemid-2)
doTeleportThing(player1.uid,nplayerpos2)  
doSendMagicEffect(nplayerpos2,10)

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1471 and statue2.itemid == 1468 and statue3.itemid == 1469 and getPlayerVocation(cid) == 4 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 

doRemoveItem(stair.uid,1)
doTransformItem(statue1.uid,statue1.itemid-2)
doTeleportThing(player1.uid,nplayerpos3)  
doSendMagicEffect(nplayerpos3,10)

---------------------------------- case 6: statue 2 is ON

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1469 and statue2.itemid == 1468 and statue3.itemid == 1469 and getPlayerVocation(cid) == 1 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 

doRemoveItem(stair.uid,1)
doTransformItem(statue2.uid,statue2.itemid-2)
doTeleportThing(player1.uid,nplayerpos1)  
doSendMagicEffect(nplayerpos1,10)

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1469 and statue2.itemid == 1468 and statue3.itemid == 1469 and getPlayerVocation(cid) == 3 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 

doRemoveItem(stair.uid,1)
doTransformItem(statue2.uid,statue2.itemid-2)
doTeleportThing(player1.uid,nplayerpos2)  
doSendMagicEffect(nplayerpos2,10)

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1469 and statue2.itemid == 1468 and statue3.itemid == 1469 and getPlayerVocation(cid) == 4 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 

doRemoveItem(stair.uid,1)
doTransformItem(statue2.uid,statue2.itemid-2)
doTeleportThing(player1.uid,nplayerpos3)  
doSendMagicEffect(nplayerpos3,10)

------------------------------ case 3: statue 3 is ON

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1469 and statue2.itemid == 1466 and statue3.itemid == 1470 and getPlayerVocation(cid) == 1 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 

doRemoveItem(stair.uid,1)
doTransformItem(statue3.uid,statue3.itemid-1)
doTeleportThing(player1.uid,nplayerpos1)  
doSendMagicEffect(nplayerpos1,10)

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1469 and statue2.itemid == 1466 and statue3.itemid == 1470 and getPlayerVocation(cid) == 3 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 

doRemoveItem(stair.uid,1)
doTransformItem(statue3.uid,statue3.itemid-1)
doTeleportThing(player1.uid,nplayerpos2)  
doSendMagicEffect(nplayerpos2,10)

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1469 and statue2.itemid == 1466 and statue3.itemid == 1470 and getPlayerVocation(cid) == 4 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 

doRemoveItem(stair.uid,1)
doTransformItem(statue3.uid,statue3.itemid-1)
doTeleportThing(player1.uid,nplayerpos3)  
doSendMagicEffect(nplayerpos3,10)

----------------------------- case 2: statue 2 & statue 3 are ON

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1469 and statue2.itemid == 1468 and statue3.itemid == 1470 and getPlayerVocation(cid) == 1 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 
doRemoveItem(stair.uid,1)
doTransformItem(statue2.uid,statue2.itemid-2)
doTransformItem(statue3.uid,statue3.itemid-1)
doTeleportThing(player1.uid,nplayerpos1)  
doSendMagicEffect(nplayerpos1,10)

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1469 and statue2.itemid == 1468 and statue3.itemid == 1470 and getPlayerVocation(cid) == 3 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 
doRemoveItem(stair.uid,1)
doTransformItem(statue2.uid,statue2.itemid-2)
doTransformItem(statue3.uid,statue3.itemid-1)
doTeleportThing(player1.uid,nplayerpos2)  
doSendMagicEffect(nplayerpos2,10)

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1469 and statue2.itemid == 1468 and statue3.itemid == 1470 and getPlayerVocation(cid) == 4 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 
doRemoveItem(stair.uid,1)
doTransformItem(statue2.uid,statue2.itemid-2)
doTransformItem(statue3.uid,statue3.itemid-1)
doTeleportThing(player1.uid,nplayerpos3)  
doSendMagicEffect(nplayerpos3,10)

----------------------------- case 7: statue 1 & statue 3 are ON

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1471 and statue2.itemid == 1466 and statue3.itemid == 1470 and getPlayerVocation(cid) == 1 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 
doRemoveItem(stair.uid,1)
doTransformItem(statue1.uid,statue1.itemid-2)
doTransformItem(statue3.uid,statue3.itemid-1)
doTeleportThing(player1.uid,nplayerpos1)  
doSendMagicEffect(nplayerpos1,10)

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1471 and statue2.itemid == 1466 and statue3.itemid == 1470 and getPlayerVocation(cid) == 3 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 
doRemoveItem(stair.uid,1)
doTransformItem(statue1.uid,statue1.itemid-2)
doTransformItem(statue3.uid,statue3.itemid-1)
doTeleportThing(player1.uid,nplayerpos2)  
doSendMagicEffect(nplayerpos2,10)

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1471 and statue2.itemid == 1466 and statue3.itemid == 1470 and getPlayerVocation(cid) == 4 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 
doRemoveItem(stair.uid,1)
doTransformItem(statue1.uid,statue1.itemid-2)
doTransformItem(statue3.uid,statue3.itemid-1)
doTeleportThing(player1.uid,nplayerpos3)  
doSendMagicEffect(nplayerpos3,10)

----------------------------- case 8: statue 1 & statue 2 are ON

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1471 and statue2.itemid == 1468 and statue3.itemid == 1469 and getPlayerVocation(cid) == 1 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 
doRemoveItem(stair.uid,1)
doTransformItem(statue1.uid,statue1.itemid-2)
doTransformItem(statue2.uid,statue2.itemid-2)
doTeleportThing(player1.uid,nplayerpos1)  
doSendMagicEffect(nplayerpos1,10)

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1471 and statue2.itemid == 1468 and statue3.itemid == 1469 and getPlayerVocation(cid) == 3 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 
doRemoveItem(stair.uid,1)
doTransformItem(statue1.uid,statue1.itemid-2)
doTransformItem(statue2.uid,statue2.itemid-2)
doTeleportThing(player1.uid,nplayerpos2)  
doSendMagicEffect(nplayerpos2,10)

elseif item.itemid == 3741 and item.uid == 9019 and statue1.itemid == 1471 and statue2.itemid == 1468 and statue3.itemid == 1469 and getPlayerVocation(cid) == 4 and player1.itemid > 0 then 
doPlayerSendTextMessage(cid,22,"You got teleported!") 
doRemoveItem(stair.uid,1)
doTransformItem(statue1.uid,statue1.itemid-2)
doTransformItem(statue2.uid,statue2.itemid-2)
doTeleportThing(player1.uid,nplayerpos3)  
doSendMagicEffect(nplayerpos3,10)





else
doPlayerSendTextMessage(cid,22,"You are not staying on a correct position.") 


end


return 1

end


