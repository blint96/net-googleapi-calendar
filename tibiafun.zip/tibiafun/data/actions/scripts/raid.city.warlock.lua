function onUse(cid, item, frompos, item2, topos)

if item.uid == 9166 and item.itemid == 1945 then
orc1pos = {x=157, y=66, z=7, stackpos=1}
orc2pos = {x=156, y=71, z=7, stackpos=1}
orc3pos = {x=151, y=63, z=7, stackpos=1}
orc4pos = {x=148, y=59, z=7, stackpos=1}
orc5pos = {x=141, y=55, z=7, stackpos=1}
orc6pos = {x=151, y=48, z=7, stackpos=1}
orc7pos = {x=155, y=46, z=7, stackpos=1}
orc8pos = {x=165, y=44, z=7, stackpos=1}
orc9pos = {x=169, y=48, z=7, stackpos=1}
orc10pos = {x=168, y=53, z=7,stackpos=1}
orc11pos = {x=171, y=59, z=7,stackpos=1}
orc12pos = {x=182, y=59, z=7,stackpos=1}
orc13pos = {x=190, y=60, z=7,stackpos=1}
orc14pos = {x=191, y=70, z=7,stackpos=1}


doSummonCreature("Warlock",orc1pos)
doSummonCreature("Warlock",orc1pos)
doSummonCreature("Warlock",orc1pos)
doSummonCreature("Warlock",orc1pos)
doSummonCreature("Warlock",orc1pos)

doSummonCreature("Warlock",orc2pos)
doSummonCreature("Warlock",orc2pos)
doSummonCreature("Warlock",orc2pos)
doSummonCreature("Warlock",orc2pos)
doSummonCreature("Warlock",orc2pos)

doSummonCreature("Warlock",orc3pos)
doSummonCreature("Warlock",orc3pos)
doSummonCreature("Warlock",orc3pos)
doSummonCreature("Warlock",orc3pos)
doSummonCreature("Warlock",orc3pos)

doSummonCreature("Warlock",orc4pos)
doSummonCreature("Warlock",orc4pos)
doSummonCreature("Warlock",orc4pos)
doSummonCreature("Warlock",orc4pos)
doSummonCreature("Warlock",orc4pos)

doSummonCreature("Warlock",orc5pos)
doSummonCreature("Warlock",orc5pos)
doSummonCreature("Warlock",orc5pos)
doSummonCreature("Warlock",orc5pos)
doSummonCreature("Warlock",orc5pos)

doSummonCreature("Warlock",orc6pos)
doSummonCreature("Warlock",orc6pos)
doSummonCreature("Warlock",orc6pos)
doSummonCreature("Warlock",orc6pos)
doSummonCreature("Warlock",orc6pos)

doSummonCreature("Warlock",orc7pos)
doSummonCreature("Warlock",orc7pos)
doSummonCreature("Warlock",orc7pos)
doSummonCreature("Warlock",orc7pos)
doSummonCreature("Warlock",orc7pos)

doSummonCreature("Warlock",orc8pos)
doSummonCreature("Warlock",orc8pos)
doSummonCreature("Warlock",orc8pos)
doSummonCreature("Warlock",orc8pos)
doSummonCreature("Warlock",orc8pos)

doSummonCreature("Warlock",orc9pos)
doSummonCreature("Warlock",orc9pos)
doSummonCreature("Warlock",orc9pos)
doSummonCreature("Warlock",orc9pos)
doSummonCreature("Warlock",orc9pos)

doSummonCreature("Warlock",orc10pos)
doSummonCreature("Warlock",orc10pos)
doSummonCreature("Warlock",orc10pos)
doSummonCreature("Warlock",orc10pos)
doSummonCreature("Warlock",orc10pos)

doSummonCreature("Warlock",orc11pos)
doSummonCreature("Warlock",orc11pos)
doSummonCreature("Warlock",orc11pos)
doSummonCreature("Warlock",orc11pos)
doSummonCreature("Warlock",orc11pos)

doSummonCreature("Warlock",orc12pos)
doSummonCreature("Warlock",orc12pos)
doSummonCreature("Warlock",orc12pos)
doSummonCreature("Warlock",orc12pos)
doSummonCreature("Warlock",orc12pos)

doSummonCreature("Warlock",orc13pos)
doSummonCreature("Warlock",orc13pos)
doSummonCreature("Warlock",orc13pos)
doSummonCreature("Warlock",orc13pos)
doSummonCreature("Warlock",orc13pos)

doSummonCreature("Warlock",orc14pos)
doSummonCreature("Warlock",orc14pos)
doSummonCreature("Warlock",orc14pos)
doSummonCreature("Warlock",orc14pos)
doSummonCreature("Warlock",orc14pos)



doSendMagicEffect(orc1pos,10)
doSendMagicEffect(orc2pos,10)
doSendMagicEffect(orc3pos,10)
doSendMagicEffect(orc4pos,10)
doSendMagicEffect(orc5pos,10)
doSendMagicEffect(orc6pos,10)
doSendMagicEffect(orc7pos,10)
doSendMagicEffect(orc8pos,10)
doSendMagicEffect(orc9pos,10)
doSendMagicEffect(orc10pos,10)
doSendMagicEffect(orc11pos,10)
doSendMagicEffect(orc12pos,10)
doSendMagicEffect(orc13pos,10)
doSendMagicEffect(orc14pos,10)



doPlayerSay(cid,'/nbc green The Warlocks have conquered The City. Fight them back to the hell where they came from!!',23)
	doTransformItem(item.uid,item.itemid+1)
else 
doTransformItem(item.uid,item.itemid-1)	
end
return 1
end