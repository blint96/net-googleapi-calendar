function onUse(cid, item, frompos, item2, topos)
-- Working watch - by Alreth (v1.35)
    twentyfour = true -- Set to true to use 24-hour clock and false to use 12-hour clock
    tibiantime = false -- Set to true to show Tibian ingame time and false to show the time on the server computer.
    
    if (tibiantime == false) then
        if (twentyfour == true) then
            time = os.date('%H:%M')
        else
            time = os.date('%I:%M %p')
        end
    else
        time = tibiatime()
    end
    doPlayerSendTextMessage(cid, 22, "The time is "..time..".")
    return 1
end