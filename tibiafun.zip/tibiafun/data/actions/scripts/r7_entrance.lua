function onUse(cid, item, frompos, item2, topos)
	
	
	
    wallpos1 = {x=258, y=884, z=5, stackpos=1} 
    wall1 = getThingfromPos(wallpos1)
	
	wallpos2 = {x=261, y=884, z=5, stackpos=1} 
    wall2 = getThingfromPos(wallpos2)
	
	item1pos = {x=258, y=886, z=5, stackpos=255}
    item1 = getThingfromPos(item1pos)
	
	item2pos = {x=260, y=886, z=5, stackpos=255}
    item2 = getThingfromPos(item2pos)
	
	item3pos = {x=258, y=888, z=5, stackpos=255}
    item3 = getThingfromPos(item3pos)
	
	item4pos = {x=260, y=888, z=5, stackpos=255}
    item4 = getThingfromPos(item4pos)
	
	forwleverpos = {x=257, y=882, z=5, stackpos=1} 
    forwlever = getThingfromPos(forwleverpos)
	
	floortilepos = {x=259, y=880, z=5, stackpos=1} 
floortile = getThingfromPos(floortilepos) 
	

	
    if item1.itemid == 2014 and item1.type == 1 then
	if item2.itemid == 2014 and item2.type == 3 then
	if item3.itemid == 2014 and item3.type == 5 then
	if item4.itemid == 2014 and item4.type == 15 then
	
   	if item.uid == 9015 and item.itemid == 1945 then
	 
	doTransformItem(item.uid,item.itemid+1)
	
	doTransformItem(wall1.uid,1162)
	doTransformItem(wall2.uid,1162)
	
	doTransformItem(forwlever.uid,1945)
	doTransformItem(floortile.uid,1164)
	
	

	
	doRemoveItem(item1.uid,1)
	doRemoveItem(item2.uid,1)
	doRemoveItem(item3.uid,1)
	doRemoveItem(item4.uid,1)
	
	doSendMagicEffect(item1pos,2)
	doSendMagicEffect(item2pos,2)
	doSendMagicEffect(item3pos,2)
	doSendMagicEffect(item4pos,2)

    doSendMagicEffect(wallpos1,2)
	doSendMagicEffect(wallpos2,2)	
	
	
	
	

	
	
	elseif item.uid == 9015 and item.itemid == 1946 then
	doTransformItem(item.uid,item.itemid-1)
	doPlayerSendTextMessage(cid,22,"Wall created again.") 
	
	doSendMagicEffect(wallpos1,2)
	doSendMagicEffect(wallpos2,2)
	
	doTransformItem(forwlever.uid,1946)
	
	doTransformItem(wall1.uid,1164)
	doTransformItem(wall1.uid,1164)
	doTransformItem(floortile.uid,1162)

	else
		doPlayerSendTextMessage(cid,22,"Lever position valid.") 
		end
		
		else
		doPlayerSendTextMessage(cid,22,"Wrong kind of drink at place NE,SW,SW.") 
		end
		
	else
	doPlayerSendTextMessage(cid,22,"Wrong kind of drink at place SW,SE.") 
	end
	
	else
	doPlayerSendTextMessage(cid,22,"Wrong kind of drink at place SE.") 
	end
	
	else
	doPlayerSendTextMessage(cid,22,"Drinks in wrong order.") 
	end
	

	
		
	
	return 1
end
