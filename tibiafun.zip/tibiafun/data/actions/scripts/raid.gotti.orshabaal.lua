function onUse(cid, item, frompos, item2, topos)

if item.uid == 9167 and item.itemid == 1945 then
orc1pos = {x=573, y=623, z=7, stackpos=1}
orc2pos = {x=583, y=624, z=7, stackpos=1}
orc3pos = {x=593, y=624, z=7, stackpos=1}
orc4pos = {x=601, y=625, z=7, stackpos=1}
orc5pos = {x=607, y=627, z=7, stackpos=1}
orc6pos = {x=606, y=622, z=7, stackpos=1}
orc7pos = {x=604, y=637, z=7, stackpos=1}
orc8pos = {x=595, y=637, z=7, stackpos=1}
orc9pos = {x=616, y=628, z=7, stackpos=1}
orc10pos = {x=623, y=628, z=7,stackpos=1}
orc11pos = {x=626, y=624, z=7,stackpos=1}
orc12pos = {x=624, y=611, z=7,stackpos=1}
orc13pos = {x=615, y=611, z=7,stackpos=1}
orc14pos = {x=623, y=603, z=7,stackpos=1}
orc15pos = {x=638, y=629, z=7,stackpos=1}
orc16pos = {x=632, y=634, z=7,stackpos=1}
orc17pos = {x=617, y=620, z=7,stackpos=1}


doSummonCreature("orshabaal",orc1pos)
doSummonCreature("orshabaal",orc1pos)
doSummonCreature("orshabaal",orc1pos)
doSummonCreature("orshabaal",orc1pos)
doSummonCreature("orshabaal",orc1pos)

doSummonCreature("orshabaal",orc2pos)
doSummonCreature("orshabaal",orc2pos)
doSummonCreature("orshabaal",orc2pos)
doSummonCreature("orshabaal",orc2pos)
doSummonCreature("orshabaal",orc2pos)

doSummonCreature("orshabaal",orc3pos)
doSummonCreature("orshabaal",orc3pos)
doSummonCreature("orshabaal",orc3pos)
doSummonCreature("orshabaal",orc3pos)
doSummonCreature("orshabaal",orc3pos)

doSummonCreature("orshabaal",orc4pos)
doSummonCreature("orshabaal",orc4pos)
doSummonCreature("orshabaal",orc4pos)
doSummonCreature("orshabaal",orc4pos)
doSummonCreature("orshabaal",orc4pos)

doSummonCreature("orshabaal",orc5pos)
doSummonCreature("orshabaal",orc5pos)
doSummonCreature("orshabaal",orc5pos)
doSummonCreature("orshabaal",orc5pos)
doSummonCreature("orshabaal",orc5pos)

doSummonCreature("orshabaal",orc6pos)
doSummonCreature("orshabaal",orc6pos)
doSummonCreature("orshabaal",orc6pos)
doSummonCreature("orshabaal",orc6pos)
doSummonCreature("orshabaal",orc6pos)

doSummonCreature("orshabaal",orc7pos)
doSummonCreature("orshabaal",orc7pos)
doSummonCreature("orshabaal",orc7pos)
doSummonCreature("orshabaal",orc7pos)
doSummonCreature("orshabaal",orc7pos)

doSummonCreature("orshabaal",orc8pos)
doSummonCreature("orshabaal",orc8pos)
doSummonCreature("orshabaal",orc8pos)
doSummonCreature("orshabaal",orc8pos)
doSummonCreature("orshabaal",orc8pos)

doSummonCreature("orshabaal",orc9pos)
doSummonCreature("orshabaal",orc9pos)
doSummonCreature("orshabaal",orc9pos)
doSummonCreature("orshabaal",orc9pos)
doSummonCreature("orshabaal",orc9pos)

doSummonCreature("orshabaal",orc10pos)
doSummonCreature("orshabaal",orc10pos)
doSummonCreature("orshabaal",orc10pos)
doSummonCreature("orshabaal",orc10pos)
doSummonCreature("orshabaal",orc10pos)

doSummonCreature("orshabaal",orc11pos)
doSummonCreature("orshabaal",orc11pos)
doSummonCreature("orshabaal",orc11pos)
doSummonCreature("orshabaal",orc11pos)
doSummonCreature("orshabaal",orc11pos)

doSummonCreature("orshabaal",orc12pos)
doSummonCreature("orshabaal",orc12pos)
doSummonCreature("orshabaal",orc12pos)
doSummonCreature("orshabaal",orc12pos)
doSummonCreature("orshabaal",orc12pos)

doSummonCreature("orshabaal",orc13pos)
doSummonCreature("orshabaal",orc13pos)
doSummonCreature("orshabaal",orc13pos)
doSummonCreature("orshabaal",orc13pos)
doSummonCreature("orshabaal",orc13pos)

doSummonCreature("orshabaal",orc14pos)
doSummonCreature("orshabaal",orc14pos)
doSummonCreature("orshabaal",orc14pos)
doSummonCreature("orshabaal",orc14pos)
doSummonCreature("orshabaal",orc14pos)

doSummonCreature("orshabaal",orc15pos)
doSummonCreature("orshabaal",orc15pos)
doSummonCreature("orshabaal",orc15pos)
doSummonCreature("orshabaal",orc15pos)
doSummonCreature("orshabaal",orc15pos)

doSummonCreature("orshabaal",orc16pos)
doSummonCreature("orshabaal",orc16pos)
doSummonCreature("orshabaal",orc16pos)
doSummonCreature("orshabaal",orc16pos)
doSummonCreature("orshabaal",orc16pos)

doSummonCreature("orshabaal",orc17pos)
doSummonCreature("orshabaal",orc17pos)
doSummonCreature("orshabaal",orc17pos)
doSummonCreature("orshabaal",orc17pos)
doSummonCreature("orshabaal",orc17pos)



doSendMagicEffect(orc1pos,10)
doSendMagicEffect(orc2pos,10)
doSendMagicEffect(orc3pos,10)
doSendMagicEffect(orc4pos,10)
doSendMagicEffect(orc5pos,10)
doSendMagicEffect(orc6pos,10)
doSendMagicEffect(orc7pos,10)
doSendMagicEffect(orc8pos,10)
doSendMagicEffect(orc9pos,10)
doSendMagicEffect(orc10pos,10)
doSendMagicEffect(orc11pos,10)
doSendMagicEffect(orc12pos,10)
doSendMagicEffect(orc13pos,10)
doSendMagicEffect(orc14pos,10)
doSendMagicEffect(orc15pos,10)
doSendMagicEffect(orc16pos,10)
doSendMagicEffect(orc17pos,10)

doPlayerSay(cid,'/nbc green The Orshabaals have conquered Gotti. Fight them back to the hell where they came from!!',23)
	doTransformItem(item.uid,item.itemid+1)
else 
	doTransformItem(item.uid,item.itemid-1)	
end
return 1
end