function onUse(cid, item, frompos, item2, topos)

stairpos = {x=260, y=878, z=1, stackpos=1}   
stair = getThingfromPos(stairpos)  
--statusclickeda = getPlayerStorageValue(cid,9501) 

cobra_status1 = getPlayerStorageValue(cid,9501)
cobra_status2 = getPlayerStorageValue(cid,9502)
cobra_status3 = getPlayerStorageValue(cid,9503)


if item.itemid == 1469 and item.uid == 9501 then
doTransformItem(item.uid,item.itemid+2)
doPlayerSendTextMessage(cid,22,"1st Cobra created.") 
setPlayerStorageValue(cid,9501,1) 

elseif item.itemid == 1466 and item.uid == 9502 and cobra_status1 == 1 then
doTransformItem(item.uid,item.itemid+2) 
doPlayerSendTextMessage(cid,22,"2nd Cobra created.") 
setPlayerStorageValue(cid,9502,1) 

elseif item.itemid == 1469 and item.uid == 9503 and cobra_status2 == 1 then
doTransformItem(item.uid,item.itemid+1) 
doPlayerSendTextMessage(cid,22,"3rd Cobra created.") 
doSendMagicEffect(stairpos, 2) 
doCreateItem(3687,1,stairpos) 
print("Stairs 2 on R7Q Created.")
setPlayerStorageValue(cid,9503,1) 

elseif item.uid == 9501 and item.itemid == 1471 then
doTransformItem(item.uid,item.itemid-2)
doSendMagicEffect(stairpos, 2) 
doRemoveItem(stair.uid,1)

elseif item.uid == 9502 and item.itemid == 1468 then
doTransformItem(item.uid,item.itemid-2)
doSendMagicEffect(stairpos, 2) 
doRemoveItem(stair.uid,1)

elseif item.uid == 9503 and item.itemid == 1470 then
doTransformItem(item.uid,item.itemid-1)
doSendMagicEffect(stairpos, 2) 
doRemoveItem(stair.uid,1)


else
doPlayerSendTextMessage(cid,22,"Push statues in the correct order!") 
print("R7Q - Player pushed statue in the wrong order")


end

return 1

end


