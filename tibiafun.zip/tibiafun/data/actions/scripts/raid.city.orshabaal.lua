function onUse(cid, item, frompos, item2, topos)

if item.uid == 9169 and item.itemid == 1945 then
orc1pos = {x=157, y=66, z=7, stackpos=1}
orc2pos = {x=156, y=71, z=7, stackpos=1}
orc3pos = {x=151, y=63, z=7, stackpos=1}
orc4pos = {x=148, y=59, z=7, stackpos=1}
orc5pos = {x=141, y=55, z=7, stackpos=1}
orc6pos = {x=151, y=48, z=7, stackpos=1}
orc7pos = {x=155, y=46, z=7, stackpos=1}
orc8pos = {x=165, y=44, z=7, stackpos=1}
orc9pos = {x=169, y=48, z=7, stackpos=1}
orc10pos = {x=168, y=53, z=7,stackpos=1}
orc11pos = {x=171, y=59, z=7,stackpos=1}
orc12pos = {x=182, y=59, z=7,stackpos=1}
orc13pos = {x=190, y=60, z=7,stackpos=1}
orc14pos = {x=191, y=70, z=7,stackpos=1}


doSummonCreature("Orshabaal",orc1pos)
doSummonCreature("Orshabaal",orc1pos)

doSummonCreature("Orshabaal",orc2pos)
doSummonCreature("Orshabaal",orc2pos)

doSummonCreature("Orshabaal",orc3pos)
doSummonCreature("Orshabaal",orc3pos)

doSummonCreature("Orshabaal",orc4pos)
doSummonCreature("Orshabaal",orc4pos)

doSummonCreature("Orshabaal",orc5pos)
doSummonCreature("Orshabaal",orc5pos)

doSummonCreature("Orshabaal",orc6pos)
doSummonCreature("Orshabaal",orc6pos)

doSummonCreature("Orshabaal",orc7pos)
doSummonCreature("Orshabaal",orc7pos)

doSummonCreature("Orshabaal",orc8pos)
doSummonCreature("Orshabaal",orc8pos)

doSummonCreature("Orshabaal",orc9pos)
doSummonCreature("Orshabaal",orc9pos)

doSummonCreature("Orshabaal",orc10pos)
doSummonCreature("Orshabaal",orc10pos)

doSummonCreature("Orshabaal",orc11pos)
doSummonCreature("Orshabaal",orc11pos)

doSummonCreature("Orshabaal",orc12pos)
doSummonCreature("Orshabaal",orc12pos)

doSummonCreature("Orshabaal",orc13pos)
doSummonCreature("Orshabaal",orc13pos)

doSummonCreature("Orshabaal",orc14pos)
doSummonCreature("Orshabaal",orc14pos)




doSendMagicEffect(orc1pos,12)
doSendMagicEffect(orc2pos,12)
doSendMagicEffect(orc3pos,12)
doSendMagicEffect(orc4pos,12)
doSendMagicEffect(orc5pos,12)
doSendMagicEffect(orc6pos,12)
doSendMagicEffect(orc7pos,12)
doSendMagicEffect(orc8pos,12)
doSendMagicEffect(orc9pos,12)
doSendMagicEffect(orc10pos,12)
doSendMagicEffect(orc11pos,12)
doSendMagicEffect(orc12pos,12)
doSendMagicEffect(orc13pos,12)
doSendMagicEffect(orc14pos,12)



doPlayerSay(cid,'/nbc green The Orshabaals have conquered The City. Fight them back to the hell where they came from!!',23)
	doTransformItem(item.uid,item.itemid+1)
else 
doTransformItem(item.uid,item.itemid-1)	
end
return 1
end