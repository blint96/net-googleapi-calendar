function onUse(cid, item, frompos, item2, topos)

wallpos1 = {x=258, y=884, z=5, stackpos=1} 
wall1 = getThingfromPos(wallpos1)  

wallpos2 = {x=261, y=884, z=5, stackpos=1} 
wall2 = getThingfromPos(wallpos2)  

floortilepos = {x=259, y=880, z=5, stackpos=1} 
floortile = getThingfromPos(floortilepos) 

prev_leverpos = {x=259, y=887, z=5, stackpos=1} 
  prev_lever = getThingfromPos(prev_leverpos)




if item.itemid == 1945 and item.uid == 9016 and prev_lever.itemid == 1946 then 
doTransformItem(item.uid,item.itemid+1)
doPlayerSendTextMessage(cid,22,"The past is closed. A future is opened!") 
doSendMagicEffect(wallpos1, 2) 
doSendMagicEffect(wallpos2, 2) 


doTransformItem(wall1.uid,1164)
doTransformItem(wall2.uid,1164)


doTransformItem(floortile.uid,1162)

doTransformItem(prev_lever.uid,prev_lever.itemid-1)






elseif item.uid == 9016 and item.itemid == 1946 and prev_lever.itemid == 1945 then
doTransformItem(item.uid,item.itemid-1)
doSendMagicEffect(floortilepos, 2) 

doTransformItem(wall1.uid,1160)
doTransformItem(wall2.uid,1160)
doTransformItem(floortile.uid,1164)


doTransformItem(prev_lever.uid,prev_lever.itemid+1)


else
doPlayerSendTextMessage(cid,22,"Previous lever in the wrong direction.") 


end


return 1

end

